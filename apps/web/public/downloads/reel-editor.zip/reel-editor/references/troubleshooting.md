# Troubleshooting

## setup.sh says NOT READY
- **Whisper model download** or **HyperFrames npm install** failed: the sandbox couldn't reach GitHub or npm. On
  claude.ai this is the "Code execution and file creation" setting under Settings > Capabilities. Code execution
  must be on, and the domain allowlist must allow package managers (the default). If it's set to none, the user (or
  their org owner, on Team or Enterprise) has to widen it. Everything downloads inside Claude's sandbox; the user
  doesn't need a GitHub account.
- **no headless Chrome found**: run `bash S/scripts/setup.sh` again. If it still fails, report it; rendering
  needs Chrome, and the transcript, cut and storyboard can still be delivered.
- **python packages**: re-run setup; it installs numpy, scipy, opencv-python-headless, sherpa-onnx and pillow with pip.

## Transcription
- "timing: pause-aware estimate" in the header means the word-timing model wasn't available. Captions will still
  be close, but may land a word early or late around pauses. Re-run setup to fetch it.
- Wrong words on screen: correct them with `fix` in the storyboard (by word index). The audio is never changed.
- Non-English speech: the bundled Whisper model is English-only (`small.en`).

## Framing
- "NO FACE DETECTED": the clip uses typical selfie framing. View `W/layout_check.jpg` and set `layout.text_top` and
  `layout.panel_top` in the storyboard so graphics start below the chin.
- Landscape input gets center-cropped to 9:16. Warn the user if the face could be cut off.

## Render
- `render.sh wait` reports FAILED: read the log tail it prints. Common fixes: re-run `render.sh check` and fix lint
  errors; make sure build.py ran after the last storyboard change; run `bash S/scripts/setup.sh` if Chrome moved.
- Expected speed: about 10 seconds of rendering per second of video on the 1-CPU sandbox (a 45-second Reel takes about 8 minutes). Much
  slower means something else is using the CPU; don't run snapshots during a render.
- The conversation hit its tool limit mid-render: the render keeps going. On "continue", run `render.sh status W`.
- The sandbox was reset (status shows everything as todo, or W is gone): re-run from Step 1. Setup is quick on a
  re-run, and the user's upload is still in /mnt/user-data/uploads.

## Audio
- `audio.py` report: `music_under_voice_db` should be about 13 to 17. If the voice still feels buried, raise
  `levels.music_under_voice` and `levels.sfx_under_voice` by 3 to 6 and run `build.py`, `audio.py all`, `render.sh finish`
  (no re-render).
- Clicks at cuts: shouldn't happen (8 ms fades at every join). If they do, the cut landed mid-word; adjust `--remove`.

## Upload limits
- If the clip won't upload, it's probably too large. Ask for a 1080p export or a shorter clip (under about 60 s).
