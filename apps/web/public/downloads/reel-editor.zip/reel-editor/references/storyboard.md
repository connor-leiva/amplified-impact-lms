# storyboard.json

The storyboard is the whole creative plan for one video: which look, which words get emphasis, which graphic
appears when. `build.py` turns it into the HyperFrames composition, sound-effect cues and music plan. Write it after
`cut.py`, using `W/transcript_cut.txt` (new timeline, original word indices).

## Contents
1. Times and word anchors
2. Top-level fields
3. Beat types (with JSON)
4. Creative rules that make it good
5. Full example

## 1. Times and word anchors

Every time field accepts:
- `"w23"`: the moment word 23 starts (preferred, because it stays right even if timing shifts slightly)
- `"w23.end"`: the moment word 23 ends
- `14.2`: seconds on the cut timeline

Indices come from `transcript_cut.txt` (`[9.42-12.68] 36:Over 37:the 38:next 39:30 ...`). Words removed by the cut
no longer exist; build.py warns and uses the nearest one.

## 2. Top-level fields

| field | what it does | default |
|---|---|---|
| `style` | `"editorial"` (graph-paper split screens, kinetic type) or `"creator"` (stickers, highlight captions) | `"editorial"` |
| `brand` | `{"accent": "#2E5B47", "paper": "#F3EFE7", "ink": "#22201C", "neg": "#8C2B3A", "handle": "@name"}`; all optional | accent from outfit |
| `series` | small persistent tag top-left, e.g. `"day 1 of 30"` | none |
| `hook` | `{"text": "building an ai workforce", "until": "w6"}`: title over the opening; spoken words before `until` aren't captioned (the title says them) | none |
| `sections` | `[{"label": "the difference", "at": "w20"}]`: short labels that structure the talk | none |
| `big` | words set large (case and punctuation ignored), e.g. `["workforce", "30", "employees"]` | longest content word per phrase |
| `neg` | words styled as the bad side (burgundy plus ✕ in editorial; red box in creator) | none |
| `fix` | on-screen text corrections by word index: `{"w57": "", "w58": "completely"}`; `""` hides a word | none |
| `max_words` | words per caption group | 5 editorial, 3 creator |
| `beats` | the graphics (section 3) | `[]` |
| `sfx` | `"subtle"`, `"punchy"` or `"off"` | subtle (editorial), punchy (creator) |
| `music` | `{"style": "chill-house", "bpm": 112, "drop_at": "w36"}`, a style name, or `"none"`. Styles: `chill-house`, `lofi`, `upbeat`, `ambient`. `drop_at` defaults to the first `count` beat (the beat cuts out for a bar and slams back in there) | chill-house |
| `levels` | audio balance overrides in dB: `sfx_under_voice`, `music_under_voice`, `music_gap_lift`, `lufs`, `true_peak` | see SKILL.md |
| `layout` | framing overrides in px: `text_top`, `panel_top`, `glide`, `face_center` `[x, y]` | from analyze.py |

## 3. Beat types

Every beat has `type`, `start`, `end`. In editorial style, every type except `count` and `aside` slides up a
graph-paper panel (the video glides up so the face stays visible) and the captions move onto the paper. Back-to-back
panel beats less than 0.9 s apart share one panel. In creator style, everything is stickers over the video.
`icon` = any Lucide icon name (house, mail, bot, settings, users, calendar-days, clipboard-list, list-checks, rocket,
target, lightbulb, chart-line, trending-up, circle-dollar-sign, phone, message-circle, brain, zap, sparkles, heart,
star, clock, building-2, briefcase, handshake, megaphone, video, camera, pen-line, user-check, circle-check, wand-sparkles,
key-round, map-pin, ...). Close guesses are matched. `emoji` is used by the creator style (falls back to the icon).
`at` on items is optional; without it, items appear spread across the beat.

**icons**: 1 to 4 things the speaker names.
```json
{"type": "icons", "start": "w8", "end": "w19",
 "items": [{"icon": "house", "emoji": "🏡", "label": "real estate biz", "at": "w9"},
           {"icon": "bot", "emoji": "🤖", "label": "ai team", "at": "w14"}]}
```
**sticker**: one item, same fields as icons. Use it for a single strong idea.

**versus**: the old way vs the better way. The right side lands at `reveal_at`, and the left gets a ✕ (editorial) or a red scribble (creator).
```json
{"type": "versus", "start": "w21", "end": "w35", "reveal_at": "w31",
 "left": {"icon": "mail", "label": "rewrite an email"}, "right": {"icon": "settings", "label": "change how work gets done"}}
```
**checklist**: rules or requirements, each ticked as it's said; optional stamp at the end.
```json
{"type": "checklist", "start": "w60", "end": "w74", "stamp": "actually good", "stamp_at": "w73",
 "items": [{"text": "real jobs", "at": "w61"}, {"text": "real assignments", "at": "w64"}, {"text": "people checking the work", "at": "w68"}]}
```
**list**: mixed good and bad; `"mark": "x"` rows shake and buzz.
```json
{"type": "list", "start": "w41", "end": "w51",
 "items": [{"text": "what works", "mark": "check", "at": "w44"}, {"text": "what misses the mark", "mark": "x", "at": "w48"}]}
```
**flow**: a process, left to right, up to 4 steps.
```json
{"type": "flow", "start": "w80", "end": "w95",
 "steps": [{"icon": "clipboard-list", "emoji": "📋", "label": "task"}, {"icon": "bot", "emoji": "🤖", "label": "ai employee"},
           {"icon": "users", "emoji": "👀", "label": "team review"}, {"icon": "circle-check", "emoji": "✅", "label": "done"}]}
```
**count**: the big-number moment. Editorial: a full-screen paper page, the number counts up and a grid fills. Creator: number slam, grid, flash and shake. Needs 2.5 s or more. Optional `suffix` (`"%"`, `"k"`), `grid: false`.
```json
{"type": "count", "start": "w36", "end": "w42", "to": 30}
```
**aside**: a small italic (editorial) or marker-note (creator) side comment.
```json
{"type": "aside", "start": "w52", "end": "w58", "text": "(not just the polished demo)"}
```
**endcard**: follow call-to-action; the button gets tapped at `press_at`.
```json
{"type": "endcard", "start": "w120", "end": 44.3, "sub": "day 2 tomorrow", "handle": "@name", "button": "follow", "pressed": "following"}
```

## 4. Creative rules that make it good

- **Explain, don't decorate.** Each beat shows the idea in the sentence it sits under. If you can't say what a beat explains, drop it.
- **Rhythm.** A new visual every 3 to 6 seconds; never two at once. Leave a few stretches of plain kinetic type on the face, so the panels feel like moments.
- **Timing.** Start a beat on the word that introduces the idea, and end it when the speaker moves on (end it on the first word of the next idea). Item `at` times land on the word that names the item.
- **Hook.** The first 2 to 3 seconds carry the promise, e.g. "building an ai workforce". Keep it to 2 to 5 words.
- **Labels.** 3 to 6 sections, 1 to 3 lowercase words each ("day one", "the difference", "the plan", "the rules", "follow along"). They're the outline of the talk.
- **Big words.** About one per phrase: the noun or number the sentence is about. Not "really", not "just".
- **Labels on graphics.** 1 to 4 words, lowercase in editorial; the speaker's own words where possible.
- **Endcard.** Always end with one, timed to the sign-off. Use their handle if you know it.
- **On-screen fixes.** Fix slips only where the text would read wrong ("what we completely misses" becomes "what completely misses" via `"fix": {"w57": ""}`), and tell the user what you changed.
- **Length check.** A 45-second clip usually has 7 to 11 beats: hook, about 6 to 9 graphics, endcard.

## 5. Full example (editorial, about 44 s)

```json
{
  "style": "editorial",
  "series": "day 1 of 30",
  "brand": {"handle": "@yourhandle"},
  "hook": {"text": "building an ai workforce", "until": "w6"},
  "sections": [
    {"label": "day one", "at": 0}, {"label": "the difference", "at": "w20"}, {"label": "the timeline", "at": "w36"},
    {"label": "the rules", "at": "w58"}, {"label": "follow along", "at": "w118"}
  ],
  "big": ["workforce", "email", "change", "30", "employees", "real", "completely", "follow"],
  "neg": ["completely", "misses"],
  "fix": {"w57": ""},
  "beats": [
    {"type": "icons", "start": "w8", "end": "w19", "items": [{"icon": "house", "emoji": "🏡", "label": "real estate biz"}, {"icon": "bot", "emoji": "🤖", "label": "ai team"}]},
    {"type": "versus", "start": "w21", "end": "w35", "reveal_at": "w31", "left": {"icon": "mail", "label": "rewrite an email"}, "right": {"icon": "settings", "label": "change how work gets done"}},
    {"type": "count", "start": "w36", "end": "w44", "to": 30},
    {"type": "icons", "start": "w45", "end": "w57", "items": [{"icon": "bot", "label": "ai employees"}, {"icon": "user-check", "label": "real roles"}, {"icon": "briefcase", "label": "real work"}]},
    {"type": "checklist", "start": "w58", "end": "w74", "stamp": "actually good", "items": [{"text": "real jobs", "at": "w61"}, {"text": "real assignments", "at": "w64"}, {"text": "people checking the work", "at": "w68"}]},
    {"type": "list", "start": "w75", "end": "w92", "items": [{"text": "what works", "mark": "check", "at": "w80"}, {"text": "what misses the mark", "mark": "x", "at": "w87"}]},
    {"type": "aside", "start": "w95", "end": "w101", "text": "(not just the polished demo)"},
    {"type": "flow", "start": "w102", "end": "w117", "steps": [{"icon": "clipboard-list", "label": "task"}, {"icon": "bot", "label": "ai employee"}, {"icon": "users", "label": "team review"}, {"icon": "circle-check", "label": "done"}]},
    {"type": "endcard", "start": "w118", "end": 44.3, "sub": "day 2 tomorrow"}
  ],
  "sfx": "subtle",
  "music": {"style": "chill-house", "bpm": 112}
}
```
