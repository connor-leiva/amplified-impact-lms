# Looks

Two looks are built in. Both keep every graphic below the chin (from `layout.json`), keep text out of the bottom
Reels caption area (below y=1545 of 1920) and the top header, and add a gentle punch-in zoom on every jump cut so the
cuts feel intentional. The zoom is centered on the face so it never pushes the face down into the graphics.

## Editorial (default)
Calm, premium, "someone designed this". Modeled on the reference edit the client approved.
- **Kinetic type, not captions.** Lowercase Inter Tight, words build one at a time as spoken. Big words carry
  the meaning, small words connect them. Each phrase lands in a slightly different alignment.
- **Section labels.** Short lowercase pills in the brand color that outline the talk.
- **Graph-paper split screens.** The video glides up, and a soft grid-paper panel slides in underneath with white line
  icons in brand-color circles. On paper, the words turn dark and the big words take the brand color.
- **A full-screen paper page for the big number** (`count`): it counts up while a grid fills.
- **Restraint.** Burgundy plus a ✕ for the "bad" side, italic asides, quiet sound design.
- Brand color: taken from the outfit by default (an outfit in the brand color makes the whole video read as one
  intentional look). Override with `brand.accent`. Keep `accent` deep enough for white icons to read on it.

## Creator
Loud, fun, "made in CapCut by someone with taste".
- Highlight-box captions in Montserrat Black, 2 to 3 words at a time; the spoken word lights up in a box that rotates
  yellow, green and pink. Big words go yellow; `neg` words get a red box.
- Emoji stickers with thick white outlines that pop and wiggle, tilted text stickers for section labels, Permanent
  Marker notes with drawn arrows, a yellow sticky note with ticks that draw themselves, red scribble-outs, a stamp.
- Hits: camera shake and a white flash on the big moments, a riser into the number, an Instagram-style Follow
  button that gets tapped to "Following".
- Default sound is `punchy`. For "fun but not chaotic", set `sfx` to `subtle`.

## Choosing
- "Too corporate", "make it look like a creator made it", "more fun", "TikTok energy": **creator**.
- "Too busy", "cleaner", "premium", "like a designer made it", a calm reference video: **editorial**.

## Matching a reference video
If the user uploads a reference (or screenshots), study it before writing the storyboard:
1. `python3 S/scripts/analyze.py sheet --src /mnt/user-data/uploads/<ref> --out W/ref_sheet.jpg`, then view it.
2. Name what defines it: caption style (kinetic vs boxed, case, size, position), color palette, how often graphics
   appear, whether the video moves (split screens, zooms), what the sound feels like.
3. Map that to the controls you have: `style`, `brand` colors (`accent`, `paper`, `ink`), `max_words`,
   beat density and types, `sfx` level, `music` style and `levels`. Most references land close to one of the two looks
   with brand colors changed.
4. Tell the user in one or two sentences what you carried over. If the reference needs something neither look
   has (a different font, a new motion), say so and offer the closest option rather than hand-building a one-off.

Fonts available offline: Inter Tight (editorial), Montserrat 800/900 and Permanent Marker (creator), Noto Color Emoji.
Icons: the full Lucide set.
