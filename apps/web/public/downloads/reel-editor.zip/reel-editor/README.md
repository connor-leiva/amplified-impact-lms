# Reel Editor: a Claude skill

Upload a talking-head video, say "edit this into a Reel," and Claude hands back a finished, upload-ready vertical video:
- **Tight cuts.** Dead air, retakes and false starts removed, with lip sync locked.
- **Animated graphics that explain what you're saying**, timed to your words, kept below your face.
- **Kinetic captions** synced word by word.
- **Original sound effects and background music**, mixed under your voice at Instagram's loudness target.
- **Two looks:** *Editorial* (clean graph-paper split screens, premium feel) or *Creator* (emoji stickers, bold highlight captions, punchy hits).

It runs entirely inside Claude. No GitHub, no Claude Code, no editing software.

## What you need
- A paid Claude plan (Pro, Max, Team or Enterprise).
- **Code execution and file creation** turned on: Settings > Capabilities. Leave its network allowlist on the
  default (package managers). The skill downloads its tools there, inside Claude's sandbox.

## Install (2 minutes)
1. Download `reel-editor.zip`. Don't unzip it.
2. In Claude, open **Customize > Skills**, click **+**, then **Create skill > Upload a skill**, and choose the ZIP.
3. Make sure the skill is switched on.

## Use it
Start a new chat, attach your video, and say something like *"Edit this into a Reel"* or *"Make this more engaging
with animations, sound effects and music."* Claude may ask two quick questions (look and music), then it works.
Expect the first run to take a few extra minutes while it sets up, then about 10 seconds of rendering per second of
video. If Claude pauses mid-way, reply **continue**; it picks up where it left off.

You get two files: one with music, and one without, so you can add a trending sound inside Instagram or TikTok instead.

Quick follow-ups that don't need a full re-render: "make my voice louder," "turn the sound effects down," "no music."
Other changes Claude can make: "move the graphics lower," "make it look more like a creator edited it," "cleaner, less busy."

## Best results
- Film vertical (9:16), face in the upper half of the frame, good light, a quiet room.
- Keep clips under about 60 seconds. If the upload is too big, export at 1080p.
- English speech (the transcription model is English-only).
- Want it to match a style you like? Upload that video or a few screenshots. Instagram links can't be opened by Claude.

## Credits
Built on [HyperFrames](https://www.npmjs.com/package/hyperframes) (HeyGen, Apache-2.0), Whisper (OpenAI) and NVIDIA
Parakeet via sherpa-onnx (k2-fsa), GSAP, Lucide icons, and the Inter Tight, Montserrat, Permanent Marker and Noto Color
Emoji fonts. These are all downloaded inside Claude's sandbox at run time; none are bundled here. Sound effects and
music are generated from scratch on each run, so there's nothing to license.

Created by Connor Leiva.
