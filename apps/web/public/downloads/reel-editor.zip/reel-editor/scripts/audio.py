#!/usr/bin/env python3
"""Sound for Reel Editor: synthesized sound effects, an original music bed, and the final mix.

  python3 audio.py all --work WORKDIR    # make sfx + music, then mix (normal use)
  python3 audio.py mix --work WORKDIR    # re-mix only (after changing "levels" in storyboard.json and re-running build.py)

Inputs : cut_audio.wav (cut.py), cues.json + audio_plan.json (build.py)
Outputs: mix.wav (voice + sfx + music) and, when there is music, mix_nomusic.wav (voice + sfx, for adding a
         trending sound inside Instagram/TikTok instead).
Default balance (the levels the approved edit landed on): sfx about 14 dB under the voice, music about 15 dB under
the voice while she talks and lifting ~6 dB in the gaps, final loudness -14 LUFS with peaks under -1.5 dBTP.
Every sound is generated here from scratch, so there is nothing to license and no copyright claims.
"""
import argparse, json, os, re, subprocess, sys, wave
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve

SR = 48000
RNG = np.random.default_rng(7)


# ---------- io ----------
def read(path):
    w = wave.open(path)
    x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
    x = x.reshape(-1, w.getnchannels())
    return np.repeat(x, 2, axis=1) if x.shape[1] == 1 else x[:, :2]


def write(path, x):
    x = np.atleast_2d(x.T).T if x.ndim == 1 else x
    if x.shape[1] == 1:
        x = np.repeat(x, 2, axis=1)
    with wave.open(path, "wb") as o:
        o.setnchannels(2); o.setsampwidth(2); o.setframerate(SR)
        o.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes())


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"failed: {' '.join(cmd[:6])}\n{r.stderr[-1200:]}")
    return r.stderr


# ---------- dsp ----------
def filt(x, kind, f, order=2):
    f = np.atleast_1d(f) / (SR / 2)
    return sosfilt(butter(order, f if len(f) > 1 else f[0], kind, output="sos"), x, axis=0)


def tv_lowpass(x, fc):
    a = 1 - np.exp(-2 * np.pi * np.asarray(fc) / SR)
    y, s = np.empty_like(x), 0.0
    for i in range(len(x)):
        s += a[i] * (x[i] - s); y[i] = s
    return y


def tone(f, n):
    return np.sin(2 * np.pi * np.cumsum(np.broadcast_to(f, (n,))) / SR)


def norm(x, peak=0.9):
    m = np.max(np.abs(x)) or 1
    return x * (peak / m)


def stereo(x, pan=0.0):
    return np.stack([x * np.cos((pan + 1) * np.pi / 4), x * np.sin((pan + 1) * np.pi / 4)], 1) * 1.41


# ---------- sound effects ----------
def sfx_bank():
    t = lambda d: np.arange(int(d * SR)) / SR
    out = {}

    def whoosh(d, f0, f1, soft):
        tt = t(d); u = tt / d
        x = RNG.standard_normal(len(tt))
        fc = f0 + (f1 - f0) * np.sin(np.pi * np.minimum(1, u * 1.15)) ** 2
        y = tv_lowpass(tv_lowpass(x, fc), fc * 1.4)
        y = filt(y, "high", 160) * (np.sin(np.pi * u) ** (2.2 if soft else 1.6))
        return np.stack([y * (1 - 0.6 * u), y * (0.4 + 0.6 * u)], 1)

    out["whoosh"] = whoosh(0.55, 300, 3400, False)
    out["whoosh_soft"] = whoosh(0.45, 250, 1700, True)
    tt = t(0.16); out["pop"] = stereo(tone(260 + 900 * np.exp(-tt * 30), len(tt)) * np.exp(-tt * 34) * np.minimum(1, tt / 0.002)
                                      + 0.25 * RNG.standard_normal(len(tt)) * np.exp(-tt * 900))
    tt = t(0.06); out["tap"] = stereo(tone(1800, len(tt)) * np.exp(-tt * 110) + 0.5 * filt(RNG.standard_normal(len(tt)), "high", 2500) * np.exp(-tt * 700))
    tt = t(0.07); out["tick"] = stereo((tone(3200, len(tt)) + 0.3 * tone(6400, len(tt))) * np.exp(-tt * 90))
    tt = t(0.05); out["count_tick"] = stereo(tone(2400, len(tt)) * np.exp(-tt * 150))
    tt = t(0.5); br = filt(np.cumsum(RNG.standard_normal(len(tt))), "high", 140)
    out["paper"] = stereo(filt(br, "low", 2600) * np.minimum(1, tt / 0.12) * np.exp(-np.maximum(0, tt - 0.12) * 9), 0.15)
    tt = t(1.3); out["ding"] = stereo((tone(1318.5, len(tt)) + 0.25 * tone(2637, len(tt)) + 0.08 * tone(3956, len(tt)))
                                      * np.exp(-tt * 4) * np.minimum(1, tt / 0.003))
    tt = t(1.3); u = tt / 1.3
    rz = tv_lowpass(RNG.standard_normal(len(tt)), 200 * (30 ** u)) + 0.3 * tone(180 * (5 ** u), len(tt))
    out["riser"] = stereo(rz * u ** 2 * np.minimum(1, (1.3 - tt) / 0.02))
    tt = t(0.9); out["impact"] = stereo(tone(42 + 100 * np.exp(-tt * 18), len(tt)) * np.exp(-tt * 5)
                                        + 0.6 * filt(RNG.standard_normal(len(tt)), "low", 900) * np.exp(-tt * 25))
    tt = t(0.35); out["stamp"] = stereo(tone(95, len(tt)) * np.exp(-tt * 22) + 0.7 * filt(RNG.standard_normal(len(tt)), "low", 2200) * np.exp(-tt * 60))
    tt = t(0.42); sq = sum(np.sin(2 * np.pi * 98 * k * tt) / k for k in range(1, 22, 2))
    gate = ((tt < 0.17) | ((tt > 0.22) & (tt < 0.40))).astype(float)
    out["buzz"] = stereo(filt(sq * filt(gate, "low", 60), "low", 2500))
    tt = t(0.45); nz = RNG.standard_normal(len(tt))
    out["scribble"] = stereo((filt(nz, "band", [1200, 5000])) * (0.6 + 0.4 * np.sin(2 * np.pi * 17 * tt)) ** 2 * np.sin(np.pi * tt / 0.45))
    return {k: norm(v) for k, v in out.items()}


# ---------- music ----------
PRESETS = {
    "chill-house": dict(bpm=112, chords=[[57, 60, 64, 67, 71], [53, 57, 60, 64, 67], [55, 59, 62, 65, 69], [52, 55, 59, 62, 67]],
                        kick="four", hat="off", pump=0.6, keys="saw", cutoff=1700, swing=0.0, bass="off"),
    "lofi": dict(bpm=84, chords=[[50, 53, 57, 60, 64], [43, 53, 57, 59, 64], [48, 52, 55, 59, 62], [45, 48, 52, 55, 59]],
                 kick="lofi", hat="swing", pump=0.25, keys="ep", cutoff=1300, swing=0.16, bass="root", crackle=True),
    "upbeat": dict(bpm=120, chords=[[60, 64, 67, 71], [57, 60, 64, 67], [53, 57, 60, 64], [55, 59, 62, 67]],
                   kick="four", hat="sixteen", pump=0.45, keys="pluck", cutoff=3200, swing=0.0, bass="off"),
    "ambient": dict(bpm=88, chords=[[48, 55, 62, 64, 71], [45, 52, 59, 60, 67], [41, 48, 55, 57, 64], [43, 50, 57, 59, 66]],
                    kick=None, hat=None, pump=0.0, keys="pad", cutoff=1400, swing=0.0, bass="root"),
}


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def music(dur, style="chill-house", bpm=None, drop_at=None):
    P = dict(PRESETS.get(style, PRESETS["chill-house"]))
    bpm = float(bpm or P["bpm"]); beat = 60 / bpm; bar = 4 * beat
    n = int((dur + 0.5) * SR); tt = np.arange(n) / SR
    t0 = (drop_at - np.ceil(drop_at / bar) * bar) if drop_at else 0.0  # a downbeat lands exactly on the drop
    drums, bass, keys = np.zeros(n), np.zeros(n), np.zeros((n, 2))

    def add(buf, x, at):
        i = int(at * SR)
        if i >= n or i + len(x) <= 0:
            return
        x = x[max(0, -i):]; i = max(0, i)
        buf[i:i + len(x)] += x[: n - i]

    kd = np.arange(int(0.4 * SR)) / SR
    kick = tone(45 + 105 * np.exp(-kd * 35), len(kd)) * np.exp(-kd * 7) + 0.15 * np.exp(-kd * 600)
    hd = np.arange(int(0.12 * SR)) / SR
    hat = filt(RNG.standard_normal(len(hd)), "high", 7000) * np.exp(-hd * 45)
    cd = np.arange(int(0.25 * SR)) / SR
    clap = filt(RNG.standard_normal(len(cd)), "band", [900, 4200]) * (np.exp(-cd * 22) + 0.5 * np.exp(-np.abs(cd - 0.012) * 400))
    nbeats = int(np.ceil((dur - t0) / beat)) + 4
    for k in range(nbeats):
        b = t0 + k * beat
        if b < -beat:
            continue
        if P["kick"] == "four" or (P["kick"] == "lofi" and k % 4 in (0, 2)):
            add(drums, kick, b)
        if P["kick"] == "lofi" and k % 8 == 5:
            add(drums, kick * 0.7, b + beat * 0.5)
        if P["kick"] and k % 4 in (1, 3):
            add(drums, clap * (0.55 if P["kick"] == "four" else 0.7), b)
        if P["hat"] == "off":
            add(drums, hat * 0.35, b + beat / 2)
        elif P["hat"] == "swing":
            add(drums, hat * 0.22, b); add(drums, hat * 0.16, b + beat * (0.5 + P["swing"]))
        elif P["hat"] == "sixteen":
            for j in range(4):
                add(drums, hat * (0.3 if j == 2 else 0.14), b + j * beat / 4)
    nbars = int(np.ceil((dur - t0) / bar)) + 2
    for k in range(nbars):
        b0 = t0 + k * bar
        ch = P["chords"][k % len(P["chords"])]
        root = mtof(ch[0] - 24)
        L = int(bar * SR) + int(0.3 * SR); lt = np.arange(L) / SR
        if P["bass"] == "off":
            bd = np.arange(int(beat * 0.45 * SR)) / SR
            note = (tone(root, len(bd)) + 0.2 * tone(2 * root, len(bd))) * np.exp(-bd * 6) * np.minimum(1, bd / 0.005)
            for j in range(4):
                add(bass, note, b0 + j * beat + beat / 2)
        elif P["bass"] == "root":
            add(bass, tone(root, L) * np.minimum(1, lt / 0.05) * np.exp(-lt * 0.6) * np.minimum(1, (L / SR - lt) / 0.2), b0)
        voice = np.zeros((L, 2))
        for m in ch:
            f = mtof(m)
            if P["keys"] in ("saw", "pad"):
                for det, ch_i in ((-0.004, 0), (0.004, 1)):
                    ph = (np.cumsum(np.full(L, f * (1 + det))) / SR) % 1.0
                    voice[:, ch_i] += (2 * ph - 1) * 0.12
                atk = 0.03 if P["keys"] == "saw" else 0.9
                voice *= 1  # envelope applied below
            elif P["keys"] == "ep":
                for hit in (0.0, beat * (2 + P["swing"])):
                    hl = lt - hit
                    e = np.where(hl >= 0, np.exp(-np.maximum(hl, 0) * 1.1) * np.minimum(1, np.maximum(hl, 0) / 0.004), 0)
                    w = 1 + 0.003 * np.sin(2 * np.pi * 0.6 * lt)
                    s = (tone(f * w, L) + 0.3 * tone(2 * f * w, L) + 0.08 * tone(3 * f * w, L)) * e * 0.16
                    voice += np.stack([s, s], 1)
            elif P["keys"] == "pluck":
                for j in range(8):
                    hl = lt - j * beat / 2
                    e = np.where(hl >= 0, np.exp(-np.maximum(hl, 0) * 9), 0)
                    ph = (np.cumsum(np.full(L, f * (2 if j % 2 else 1))) / SR) % 1.0
                    s = (2 * ph - 1) * e * 0.05 * (1 if (j + ch.index(m)) % 3 == 0 else 0.25)
                    voice += np.stack([s, s * 0.9], 1)
        if P["keys"] in ("saw", "pad"):
            atk = 0.03 if P["keys"] == "saw" else 0.9
            env = np.minimum(1, lt / atk) * np.minimum(1, np.maximum(0, (L / SR - lt) / 0.3))
            voice *= env[:, None]
        i = int(b0 * SR)
        if i < n and i + L > 0:
            v = voice[max(0, -i):]; i = max(0, i)
            keys[i:i + len(v)] += v[: n - i]
    keys = filt(keys, "low", P["cutoff"])
    ir_t = np.arange(int(1.2 * SR)) / SR
    for c in (0, 1):
        ir = RNG.standard_normal(len(ir_t)) * np.exp(-ir_t / 0.32)
        keys[:, c] += 0.22 * fftconvolve(keys[:, c], ir / np.sqrt(np.sum(ir ** 2)) * 0.6)[:n]
    if P["pump"]:
        ph = ((tt - t0) % beat) / beat
        pump = 1 - P["pump"] * np.exp(-ph * 7)
        keys *= pump[:, None]; bass *= pump
    if drop_at:
        pre = (tt >= drop_at - bar) & (tt < drop_at)
        drums[pre] = 0; bass[pre] *= 0.0
        keys[pre] *= 0.65
        crash_t = np.arange(int(1.8 * SR)) / SR
        add(drums, filt(RNG.standard_normal(len(crash_t)), "high", 5000) * np.exp(-crash_t * 2.4) * 0.35, drop_at)
    mixb = keys + np.stack([drums * 0.9 + bass * 0.8] * 2, 1)
    if P.get("crackle"):
        cr = (RNG.random(n) > 0.9993) * RNG.standard_normal(n) * 0.25 + RNG.standard_normal(n) * 0.004
        mixb += np.stack([filt(cr, "band", [800, 6000])] * 2, 1)
    mixb = np.tanh(mixb * 1.2)
    fade = np.minimum(1, tt / 1.2) * np.minimum(1, np.maximum(0, (dur - tt) / 2.5))
    mixb *= fade[:, None]
    rms = np.sqrt(np.mean(mixb[int(1.5 * SR):int(max(2, dur - 3) * SR)] ** 2)) or 1
    return (mixb * (10 ** (-20 / 20) / rms))[: int(dur * SR)]


# ---------- mixing ----------
def db(x):
    return 20 * np.log10(np.sqrt(np.mean(np.square(x))) + 1e-9)


def loudnorm(src, dst, lufs, tp):
    flt = f"loudnorm=I={lufs}:TP={tp}:LRA=11"
    err = sh(["ffmpeg", "-hide_banner", "-i", src, "-af", flt + ":print_format=json", "-f", "null", "-"])
    m = json.loads(re.findall(r"\{[^{}]*\}", err)[-1])
    flt2 = (f"{flt}:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:"
            f"measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:print_format=json")
    err = sh(["ffmpeg", "-y", "-hide_banner", "-i", src, "-af", flt2, "-ar", str(SR), "-c:a", "pcm_s16le", dst])
    m2 = json.loads(re.findall(r"\{[^{}]*\}", err)[-1])
    return float(m2["output_i"]), float(m2["output_tp"])


def do_mix(work):
    plan = json.load(open(os.path.join(work, "audio_plan.json")))
    cues = json.load(open(os.path.join(work, "cues.json")))
    level = plan.get("sfx", "subtle")
    lv = {"sfx_under_voice": 15 if level == "subtle" else 12, "music_under_voice": 15, "music_gap_lift": 6,
          "lufs": -14, "true_peak": -1.5}
    lv.update(plan.get("levels") or {})
    vp = os.path.join(work, "voice_proc.wav")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", os.path.join(work, "cut_audio.wav"), "-af",
        "highpass=f=80,equalizer=f=250:t=q:w=1.2:g=-2,equalizer=f=3200:t=q:w=1.4:g=2.5,"
        "acompressor=threshold=-20dB:ratio=3:attack=6:release=120:makeup=2", "-ar", str(SR), vp])
    v = read(vp)
    n = len(v)
    fr = 960
    mono = v.mean(1)
    frames = mono[: n // fr * fr].reshape(-1, fr)
    fdb = 20 * np.log10(np.sqrt((frames ** 2).mean(1)) + 1e-9)
    speech = fdb > (np.percentile(fdb, 95) - 22)
    V = db(frames[speech]) if speech.any() else db(mono)
    bank = sfx_bank()
    sfx = np.zeros((n, 2))
    for c in cues:
        x = bank.get(c["sfx"])
        if x is None:
            continue
        act = x[np.abs(x).max(1) > 0.02 * np.abs(x).max()]
        g = 10 ** ((V - lv["sfx_under_voice"] + c.get("gain_db", 0) - db(act)) / 20)
        i = int(c["t"] * SR)
        if 0 <= i < n:
            seg = x[: n - i] * g
            sfx[i:i + len(seg)] += seg
    outs = {"mix_nomusic" if plan.get("music") else "mix": v + sfx}
    report = {"voice_rms_db": round(float(V), 1), "sfx_cues": len(cues)}
    if plan.get("music"):
        mp = os.path.join(work, "music.wav")
        mu = plan["music"]
        if not os.path.exists(mp) or mu.get("regen", True):
            write(mp, music(plan["duration"], mu.get("style", "chill-house"), mu.get("bpm"), mu.get("drop_at")))
        m = read(mp)
        m = np.pad(m, ((0, max(0, n - len(m))), (0, 0)))[:n]
        mfr = m.mean(1)[: n // fr * fr].reshape(-1, fr)
        M = db(mfr[speech]) if speech.any() else db(m)
        talk_g = V - lv["music_under_voice"] - M
        target = np.where(speech, talk_g, talk_g + lv["music_gap_lift"])
        sm = np.empty_like(target); s = target[0]
        for k, x in enumerate(target):  # duck fast (60 ms), recover slowly (450 ms)
            a = 1 - np.exp(-fr / SR / (0.06 if x < s else 0.45))
            s += a * (x - s); sm[k] = s
        gain = np.interp(np.arange(n), np.arange(len(sm)) * fr + fr / 2, 10 ** (sm / 20))
        m = m * gain[:, None]
        outs["mix"] = v + sfx + m
        report["music_under_voice_db"] = round(V - db(m.mean(1)[: n // fr * fr].reshape(-1, fr)[speech]), 1)
    if cues:
        report["sfx_peak_vs_voice_db"] = round(20 * np.log10(np.abs(sfx).max() + 1e-9) - 20 * np.log10(np.abs(v).max() + 1e-9), 1)
    for name, x in outs.items():
        raw = os.path.join(work, f"_{name}_raw.wav")
        write(raw, x / max(1.0, np.abs(x).max() / 0.98))
        i, tp = loudnorm(raw, os.path.join(work, f"{name}.wav"), lv["lufs"], lv["true_peak"])
        os.remove(raw)
        report[name] = f"{i:.1f} LUFS, peak {tp:.1f} dBTP"
    print(json.dumps(report, indent=1, default=float))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["all", "mix", "music", "sfx-preview"])
    ap.add_argument("--work", required=True)
    a = ap.parse_args()
    if a.cmd == "sfx-preview":  # every effect in a row, for auditioning
        bank = sfx_bank(); gap = np.zeros((int(0.4 * SR), 2))
        write(os.path.join(a.work, "sfx_preview.wav"), np.concatenate([np.concatenate([x, gap]) for x in bank.values()]) * 0.5)
        print("sfx_preview.wav:", ", ".join(bank))
    elif a.cmd == "music":
        p = json.load(open(os.path.join(a.work, "audio_plan.json")))
        mu = p.get("music") or {"style": "chill-house"}
        write(os.path.join(a.work, "music.wav"), music(p["duration"], mu.get("style", "chill-house"), mu.get("bpm"), mu.get("drop_at")))
    else:
        do_mix(a.work)
