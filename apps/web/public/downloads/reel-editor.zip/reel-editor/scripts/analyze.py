#!/usr/bin/env python3
"""Look at the footage so graphics never cover the face, and pull a brand color from the outfit.

  python3 analyze.py layout --work WORKDIR      -> layout.json + layout_check.jpg
  python3 analyze.py sheet  --src DIR|VIDEO --out sheet.jpg [--times 1,4.5,9]   -> contact sheet

layout.json holds: face box, chin line, where kinetic text starts, how far the video glides up for
split-screen panels, where the paper panel starts, and a palette (accent picked from the clothing,
the way the approved edit matched the presenter's blazer). Everything is in 1080x1920 pixels.
"""
import argparse, colorsys, glob, json, os, subprocess, sys
import numpy as np

W, H = 1080, 1920
SAFE_TOP, SAFE_BOTTOM = 230, 1545  # Reels UI: header above, caption/username below


def frames(video, n=12):
    import cv2
    cap = cv2.VideoCapture(video)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    out = []
    for k in range(n):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int((k + 0.5) * total / n))
        ok, f = cap.read()
        if ok:
            out.append(cv2.resize(f, (W, H)))
    return out


def hexc(rgb):
    return "#%02X%02X%02X" % tuple(int(max(0, min(255, round(c)))) for c in rgb)


def palette_from(px):
    """px: Nx3 RGB 0-255 from the torso. Returns accent hex or None if the outfit is neutral."""
    if len(px) < 500:
        return None
    hsv = np.array([colorsys.rgb_to_hsv(*(p / 255.0)) for p in px[:: max(1, len(px) // 6000)]])
    sat = hsv[(hsv[:, 1] > 0.22) & (hsv[:, 2] > 0.12) & (hsv[:, 2] < 0.95)]
    if len(sat) < 0.12 * len(hsv):
        return None
    hist, edges = np.histogram(sat[:, 0], bins=36, range=(0, 1))
    k = int(np.argmax(np.convolve(hist, [1, 2, 1], mode="same")))
    sel = sat[(sat[:, 0] >= edges[max(0, k - 1)]) & (sat[:, 0] <= edges[min(36, k + 2)])]
    h, s, v = np.median(sel, axis=0)
    # Deepen for legibility on cream paper: keep the hue, settle saturation and value.
    r, g, b = colorsys.hsv_to_rgb(h, min(0.75, max(0.38, s)), 0.42 if s > 0.3 else 0.36)
    return hexc((r * 255, g * 255, b * 255))


def layout(work):
    import cv2
    video = os.path.join(work, "cut.mp4")
    fr = frames(video)
    casc = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    boxes = []
    for f in fr:
        g = cv2.cvtColor(cv2.resize(f, (W // 2, H // 2)), cv2.COLOR_BGR2GRAY)
        d = casc.detectMultiScale(g, 1.1, 5, minSize=(70, 70))
        if len(d):
            x, y, w, h = max(d, key=lambda b: b[2] * b[3])
            boxes.append([x * 2, y * 2, w * 2, h * 2])
    found = len(boxes) >= max(2, len(fr) // 4)
    if found:
        fx, fy, fw, fh = (float(v) for v in np.median(np.array(boxes), axis=0))
    else:  # typical selfie framing
        fw = fh = 420.0; fx, fy = (W - fw) / 2, 330.0
    face_top = max(0.0, fy - 0.40 * fh)
    chin = fy + 1.15 * fh
    text_top = int(min(max(chin + 70, 900), 1260))
    glide = 170.0
    if chin - glide + 60 > 1180:  # face sits low: glide further, but never crop the head
        glide = min(face_top - 30, chin + 60 - 1180)
    glide = max(0.0, min(glide, face_top - 30)) if face_top > 60 else 0.0
    panel_top = int(min(max(chin - glide + 60, 820), 1200))
    px = []
    for f in fr:
        y0, y1 = int(min(H - 10, chin + 0.25 * fh)), int(min(H, chin + 2.6 * fh))
        x0, x1 = int(max(0, fx - 0.9 * fw)), int(min(W, fx + 1.9 * fw))
        if y1 - y0 > 20 and x1 - x0 > 20:
            px.append(cv2.cvtColor(f[y0:y1:6, x0:x1:6], cv2.COLOR_BGR2RGB).reshape(-1, 3))
    accent = palette_from(np.concatenate(px).astype(float)) if px else None
    out = {"width": W, "height": H, "face_found": found,
           "face": [round(fx), round(fy), round(fw), round(fh)], "face_center": [round(fx + fw / 2), round(fy + fh / 2)],
           "face_top": round(face_top), "chin": round(chin), "text_top": text_top, "glide": round(glide),
           "panel_top": panel_top, "safe_top": SAFE_TOP, "safe_bottom": SAFE_BOTTOM,
           "palette": {"accent": accent or "#2E5B47", "from_outfit": accent is not None}}
    json.dump(out, open(os.path.join(work, "layout.json"), "w"), indent=1)
    # Visual check: three frames with the face box and layout lines drawn on.
    tiles = []
    for f in [fr[0], fr[len(fr) // 2], fr[-1]] if fr else []:
        t = f.copy()
        cv2.rectangle(t, (int(fx), int(fy)), (int(fx + fw), int(fy + fh)), (0, 220, 255), 6)
        for y, col, lab in [(chin, (0, 0, 255), "chin"), (text_top, (0, 200, 0), "text"),
                            (panel_top, (255, 120, 0), "panel"), (SAFE_BOTTOM, (80, 80, 80), "IG UI")]:
            cv2.line(t, (0, int(y)), (W, int(y)), col, 5)
            cv2.putText(t, lab, (20, int(y) - 14), cv2.FONT_HERSHEY_SIMPLEX, 1.6, col, 4)
        tiles.append(cv2.resize(t, (360, 640)))
    if tiles:
        cv2.imwrite(os.path.join(work, "layout_check.jpg"), np.hstack(tiles), [cv2.IMWRITE_JPEG_QUALITY, 82])
    print(json.dumps(out, indent=1))
    print("face detected" if found else "NO FACE DETECTED: using default selfie framing; check layout_check.jpg")


def sheet(src, out, times=None, cols=4, tile_w=270):
    from PIL import Image, ImageDraw
    items = []
    if os.path.isdir(src):
        for p in sorted(glob.glob(os.path.join(src, "*.png")) + glob.glob(os.path.join(src, "*.jpg")),
                        key=lambda p: float("".join(c for c in os.path.basename(p) if c.isdigit() or c == ".").strip(".") or 0)):
            if "sheet" not in os.path.basename(p) and "contact" not in os.path.basename(p):
                items.append((os.path.basename(p).rsplit(".", 1)[0], Image.open(p).convert("RGB")))
    else:
        dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src],
                                   capture_output=True, text=True).stdout.strip() or 0)
        times = times or [round(dur * (k + 0.5) / 12, 2) for k in range(12)]
        for t in times:
            p = f"/tmp/_sheet_{t}.jpg"
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", str(t), "-i", src, "-frames:v", "1", p])
            if os.path.exists(p):
                items.append((f"{t}s", Image.open(p).convert("RGB")))
    if not items:
        sys.exit("nothing to put on the sheet")
    th = int(tile_w * 16 / 9)
    rows = (len(items) + cols - 1) // cols
    canvas = Image.new("RGB", (cols * tile_w, rows * (th + 26)), (24, 24, 24))
    d = ImageDraw.Draw(canvas)
    for k, (lab, im) in enumerate(items):
        x, y = (k % cols) * tile_w, (k // cols) * (th + 26)
        canvas.paste(im.resize((tile_w, th)), (x, y + 26))
        d.text((x + 6, y + 6), lab, fill=(255, 255, 255))
    canvas.save(out, quality=85)
    print(f"sheet: {out} ({len(items)} frames)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["layout", "sheet"])
    ap.add_argument("--work")
    ap.add_argument("--src")
    ap.add_argument("--out")
    ap.add_argument("--times")
    a = ap.parse_args()
    if a.cmd == "layout":
        layout(a.work)
    else:
        sheet(a.src, a.out, [float(t) for t in a.times.split(",")] if a.times else None)
