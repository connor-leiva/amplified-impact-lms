#!/usr/bin/env python3
"""Transcribe a talking-head clip with Whisper and give every word a start/end time.

Usage:  python3 transcribe.py INPUT_VIDEO --work WORKDIR

Writes WORKDIR/transcript.json (words, speech regions, pauses) and WORKDIR/transcript.txt
(a readable, numbered version for spotting flubs and planning the edit).

How timing works: Whisper (small.en, sherpa-onnx export) supplies the words. A small CTC model
(if setup.sh installed one) supplies word onsets, matched to Whisper's words. Words it can't match
are spread across *speech time only*, so a word never lands inside a pause.
"""
import argparse, difflib, glob, json, os, re, subprocess, sys, wave
import numpy as np

SR, HOP = 16000, 0.01


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"command failed: {' '.join(cmd)}\n{r.stderr[-1500:]}")
    return r.stdout


def load_audio(src, work):
    out = os.path.join(work, "audio16k.wav")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-vn", "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", out])
    w = wave.open(out)
    return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768.0


def speech_mask(x):
    """Return (mask per 10 ms frame, regions [[s,e]...]) using a hysteresis energy gate."""
    n = int(SR * HOP)
    fr = len(x) // n
    rms = np.sqrt((x[: fr * n].reshape(fr, n) ** 2).mean(1) + 1e-12)
    db = np.convolve(20 * np.log10(rms + 1e-9), np.ones(3) / 3, mode="same")
    floor, peak = np.percentile(db, 10), np.percentile(db, 97)
    hi = max(floor + 7.0, peak - 30.0)
    lo = hi - 4.0
    mask = np.zeros(fr, bool)
    on, quiet = False, 0
    for i, v in enumerate(db):
        if not on and v > hi:
            on, quiet = True, 0
        elif on:
            quiet = quiet + 1 if v < lo else 0
            if quiet >= 8:  # 80 ms below the low gate ends the region
                on = False
                mask[i - quiet + 1 : i + 1] = False
                continue
        mask[i] = on
    regions, start = [], None
    for i, m in enumerate(np.append(mask, False)):
        if m and start is None:
            start = i
        elif not m and start is not None:
            if i - start >= 5:  # ignore blips under 50 ms
                regions.append([start * HOP, i * HOP])
            start = None
    merged = []
    for s, e in regions:  # bridge gaps under 60 ms
        if merged and s - merged[-1][1] < 0.06:
            merged[-1][1] = e
        else:
            merged.append([s, e])
    mask[:] = False
    for s, e in merged:
        mask[int(s / HOP) : int(e / HOP)] = True
    return mask, merged, db


def chunks_from(regions, max_len=24.0, join_gap=0.6):
    chunks = []
    for s, e in regions:
        if chunks and s - chunks[-1][-1][1] < join_gap and e - chunks[-1][0][0] < max_len:
            chunks[-1].append([s, e])
        else:
            chunks.append([[s, e]])
    return [(c[0][0], c[-1][1]) for c in chunks]


def norm(w):
    return re.sub(r"[^a-z0-9']", "", w.lower().replace("’", "'"))


def syllables(w):
    w = norm(w) or "x"
    if w.isdigit():
        return 2.0 * len(w)
    return max(1, len(re.findall(r"[aeiouy]+", w))) + (0.3 if len(w) > 6 else 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("--work", required=True)
    ap.add_argument("--threads", type=int, default=os.cpu_count() or 1)
    a = ap.parse_args()
    os.makedirs(a.work, exist_ok=True)
    import sherpa_onnx

    wdir = os.environ.get("REELKIT_WHISPER") or sorted(glob.glob(os.path.expanduser(
        os.environ.get("REELKIT_HOME", "/home/claude/.reelkit") + "/models/sherpa-onnx-whisper-*")))[0]
    name = os.path.basename(wdir).replace("sherpa-onnx-whisper-", "")
    rec = sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=f"{wdir}/{name}-encoder.int8.onnx", decoder=f"{wdir}/{name}-decoder.int8.onnx",
        tokens=f"{wdir}/{name}-tokens.txt", language="en", task="transcribe", num_threads=a.threads)
    aligner = None
    rk = os.environ.get("REELKIT_HOME", "/home/claude/.reelkit")
    adir = os.environ.get("REELKIT_ALIGN") or next(iter(sorted(glob.glob(rk + "/models/sherpa-onnx-nemo-*"))), "")
    if adir and os.path.isdir(adir):
        try:
            mdl = sorted(glob.glob(adir + "/*int8*.onnx")) or sorted(glob.glob(adir + "/*.onnx"))
            aligner = sherpa_onnx.OfflineRecognizer.from_nemo_ctc(model=mdl[0], tokens=adir + "/tokens.txt", num_threads=a.threads)
        except Exception as ex:  # timing falls back gracefully
            print("note: aligner unavailable:", ex)

    x = load_audio(a.src, a.work)
    dur = len(x) / SR
    mask, regions, _ = speech_mask(x)
    if not regions:
        sys.exit("No speech found in this clip.")
    S = np.concatenate([[0.0], np.cumsum(mask) * HOP])  # cumulative speech time per frame edge

    def s_of(t):
        return S[min(len(S) - 1, max(0, int(round(t / HOP))))]

    nxt = np.full(len(mask) + 1, len(mask))  # next speech frame at or after each frame
    for i in range(len(mask) - 1, -1, -1):
        nxt[i] = i if mask[i] else nxt[i + 1]

    def t_of(v):  # inverse of s_of; a start that lands in a pause moves to where speech resumes
        i = int(np.searchsorted(S, v - 1e-9, side="left"))
        return float(nxt[min(i, len(mask))]) * HOP

    words = []
    for cs, ce in chunks_from(regions):
        p0, p1 = max(0, cs - 0.15), min(dur, ce + 0.15)
        seg = x[int(p0 * SR) : int(p1 * SR)]
        st = rec.create_stream(); st.accept_waveform(SR, seg); rec.decode_stream(st)
        text = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", st.result.text).strip()
        ww = [w for w in text.split() if norm(w)]
        if not ww:
            continue
        anchors = {}
        if aligner is not None:
            st2 = aligner.create_stream(); st2.accept_waveform(SR, seg); aligner.decode_stream(st2)
            cw = []  # (word, start)
            for tok, ts in zip(st2.result.tokens, st2.result.timestamps):
                if tok.startswith("▁") or tok.startswith(" ") or not cw:
                    cw.append([tok.lstrip("▁ "), p0 + ts])
                else:
                    cw[-1][0] += tok
            sm = difflib.SequenceMatcher(None, [norm(w) for w in ww], [norm(c[0]) for c in cw], autojunk=False)
            for blk in sm.get_matching_blocks():
                for k in range(blk.size):
                    anchors[blk.a + k] = max(cs, cw[blk.b + k][1] - 0.04)
        # Fill every word's start: anchors where known, speech-time interpolation elsewhere.
        wts = [syllables(w) + 0.35 for w in ww]
        known = sorted(anchors.items())
        pts = [(-1, cs)] + [(i, t) for i, t in known if i >= 0] + [(len(ww), ce)]
        starts = [None] * len(ww)
        for (ia, ta), (ib, tb) in zip(pts, pts[1:]):
            lo, hi = max(ia, 0), ib  # words lo..hi-1 live between ta and tb
            if ia >= 0:
                starts[ia] = ta
            run = list(range(lo, hi))
            if not run:
                continue
            tot = sum(wts[k] for k in run)
            sa, sb = s_of(ta), s_of(tb)
            acc = 0.0
            for k in run:
                if starts[k] is None:
                    starts[k] = t_of(sa + (sb - sa) * acc / tot)
                acc += wts[k]
        for i in range(1, len(starts)):  # keep order strictly increasing
            starts[i] = max(starts[i], starts[i - 1] + 0.04)
        for i, w in enumerate(ww):
            words.append({"w": w, "start": round(starts[i], 3), "anchored": i in anchors})

    # Word ends: next word's start, or the end of the speech region the word sits in.
    for i, w in enumerate(words):
        nxt = words[i + 1]["start"] if i + 1 < len(words) else dur
        reg_end = next((e for s, e in regions if s - 0.05 <= w["start"] < e), w["start"] + 0.3)
        w["end"] = round(max(w["start"] + 0.06, min(nxt - 0.01, reg_end)), 3)
        w["i"] = i
    pauses = [[round(e, 2), round(s2, 2)] for (s, e), (s2, e2) in zip(regions, regions[1:]) if s2 - e >= 0.25]
    out = {"source": os.path.abspath(a.src), "duration": round(dur, 3), "model": f"whisper-{name}",
           "aligned": aligner is not None, "speech": [[round(s, 3), round(e, 3)] for s, e in regions],
           "pauses": pauses, "words": [{k: w[k] for k in ("i", "w", "start", "end", "anchored")} for w in words],
           "text": " ".join(w["w"] for w in words)}
    json.dump(out, open(os.path.join(a.work, "transcript.json"), "w"), indent=1)

    lines = [f"# {dur:.2f}s clip | {len(words)} words | speech {sum(e - s for s, e in regions):.1f}s | "
             f"timing: {'aligned' if aligner else 'pause-aware estimate'}",
             "# Format: [start-end] then index:word. Use indices (w12) in --remove and in storyboard.json."]
    cur = []
    for i, w in enumerate(words):
        cur.append(w)
        gap = (words[i + 1]["start"] - w["end"]) if i + 1 < len(words) else 9
        if gap >= 0.3 or len(cur) >= 12 or (w["w"][-1] in ".?!" and len(cur) >= 3):
            lines.append(f"[{cur[0]['start']:6.2f}-{cur[-1]['end']:6.2f}] " + " ".join(f"{c['i']}:{c['w']}" for c in cur)
                         + (f"   <pause {gap:.2f}s>" if 0.3 <= gap < 9 else ""))
            cur = []
    open(os.path.join(a.work, "transcript.txt"), "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
