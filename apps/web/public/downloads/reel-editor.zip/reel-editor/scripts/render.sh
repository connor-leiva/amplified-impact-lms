#!/usr/bin/env bash
# Reel Editor render helper (HyperFrames).
#   render.sh check  WORK          lint + snapshot frames -> WORK/check/sheet.jpg (look at it before rendering)
#   render.sh start  WORK          start the full render in the background (survives between tool calls)
#   render.sh wait   WORK [secs]   wait up to secs (default 280) and report progress
#   render.sh finish WORK [name]   add the final mix, write MP4s to /mnt/user-data/outputs, make a QA sheet
#   render.sh status WORK          which steps are done (use this when resuming after "continue")
set -uo pipefail
RK="${REELKIT_HOME:-/home/claude/.reelkit}"; [ -f "$RK/env.sh" ] && source "$RK/env.sh"
CMD="${1:-}"; WORK="${2:-}"
if [ -z "$CMD" ] || [ -z "$WORK" ]; then sed -n '2,8p' "$0"; exit 1; fi
HERE="$(cd "$(dirname "$0")" && pwd)"; PROJ="$WORK/project"; HF="$RK/node/node_modules/.bin/hyperframes"
OUTDIR="${REELKIT_OUT:-/mnt/user-data/outputs}"
strip(){ sed 's/\x1b\[[0-9;]*[A-Za-z]//g' | tr '\r' '\n'; }
running(){ [ -f "$WORK/render.pid" ] && kill -0 "$(cat "$WORK/render.pid")" 2>/dev/null; }
case "$CMD" in
  check)
    echo "== lint"; "$HF" lint "$PROJ" 2>&1 | strip | grep -v -E "^\s*$|telemetry|anonymous" | tail -12
    T="$(cat "$WORK/snapshot_times.txt")"; rm -rf "$WORK/check"; mkdir -p "$WORK/check"
    echo "== snapshots at $T"
    timeout 900 "$HF" snapshot "$PROJ" --at "$T" --no-end -o "$WORK/check" 2>&1 | strip | grep -v -E "^\s*$" | tail -3
    python3 "$HERE/analyze.py" sheet --src "$WORK/check" --out "$WORK/check/sheet.jpg" ;;
  start)
    if running; then echo "already rendering"; exit 0; fi
    rm -f "$WORK/render.mp4" "$WORK/render.done"
    setsid nohup bash -c "'$HF' render '$PROJ' -o '$WORK/render.mp4' --quality looks --workers 1 > '$WORK/render.log' 2>&1; echo \$? > '$WORK/render.done'" >/dev/null 2>&1 < /dev/null &
    echo $! > "$WORK/render.pid"; date +%s > "$WORK/render.start"
    D=$(python3 -c "import json;print(json.load(open('$WORK/cuts.json'))['duration'])")
    echo "render started for ${D}s of video. Expect about $(python3 -c "print(max(1, round($D*10/60)))") min (about 10 s of rendering per second of video)." ;;
  wait)
    LIM="${3:-280}"; S=$(date +%s)
    while [ ! -f "$WORK/render.done" ] && [ $(( $(date +%s) - S )) -lt "$LIM" ]; do sleep 10; done
    EL=$(( $(date +%s) - $(cat "$WORK/render.start" 2>/dev/null || date +%s) ))
    if [ -f "$WORK/render.done" ]; then
      RC=$(cat "$WORK/render.done")
      if [ "$RC" = "0" ] && [ -s "$WORK/render.mp4" ]; then echo "RENDER DONE in $((EL/60))m$((EL%60))s"; else echo "RENDER FAILED (exit $RC):"; strip < "$WORK/render.log" | grep -v "^\s*$" | tail -15; fi
    else
      echo "still rendering after $((EL/60))m$((EL%60))s:"; strip < "$WORK/render.log" | grep -v "^\s*$" | tail -2
    fi ;;
  finish)
    NAME="${3:-reel}"; R="$WORK/render.mp4"; [ -s "$R" ] || { echo "no render.mp4 yet"; exit 1; }
    mkdir -p "$OUTDIR"
    [ -f "$WORK/mix.wav" ] || { echo "no mix.wav yet; using the raw edited voice"; cp "$WORK/cut_audio.wav" "$WORK/mix.wav"; }
    for pair in "mix:$NAME" "mix_nomusic:$NAME-no-music"; do
      A="$WORK/${pair%%:*}.wav"; O="$OUTDIR/${pair#*:}.mp4"
      [ -f "$A" ] || continue
      ffmpeg -y -loglevel error -i "$R" -i "$A" -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 256k -ar 48000 -shortest -movflags +faststart "$O" \
        && echo "wrote $O ($(du -h "$O" | cut -f1), $(ffprobe -v error -show_entries format=duration -of csv=p=0 "$O")s)"
    done
    python3 "$HERE/analyze.py" sheet --src "$OUTDIR/$NAME.mp4" --out "$WORK/final_sheet.jpg" ;;
  status)
    for f in transcript.json cut.mp4 layout.json storyboard.json project/index.html check/sheet.jpg mix.wav render.mp4; do
      [ -e "$WORK/$f" ] && echo "done  $f" || echo "todo  $f"; done
    running && echo "render: RUNNING" || { [ -f "$WORK/render.done" ] && echo "render: finished (exit $(cat "$WORK/render.done"))"; } ;;
  *) sed -n '2,8p' "$0"; exit 1 ;;
esac
