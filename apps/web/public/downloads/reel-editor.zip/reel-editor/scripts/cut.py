#!/usr/bin/env python3
"""Remove dead space (and any flubs you name) with frame-exact, sync-safe cuts.

Usage:
  python3 cut.py --work WORKDIR [--max-gap 0.30] [--pad-in 0.06] [--pad-out 0.10]
                 [--remove "w10-w15,31.2-32.0"] [--fps 30]

Needs WORKDIR/transcript.json from transcribe.py. Writes:
  cut.mp4          1080x1920 CFR video with the edited audio (the HyperFrames background)
  cut_audio.wav    48 kHz stereo dialogue for the mixer
  words_cut.json   every kept word, re-timed to the new timeline (same word indices)
  transcript_cut.txt  numbered transcript on the new timeline (use it to write storyboard.json)
  cuts.json        jump-cut times on the new timeline (used for punch-in zooms)

Why it is built this way: one big ffmpeg filter graph runs out of memory in a 4 GB sandbox, and
AAC-encoded segments drift at every join. So video segments are encoded one at a time with exact
frame counts, and audio is sliced from one WAV by sample index (sr/fps samples per frame), so
picture and sound stay locked no matter how many cuts there are.
"""
import argparse, json, math, os, re, subprocess, sys, wave
import numpy as np

W, H, ASR = 1080, 1920, 48000


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"command failed: {' '.join(cmd[:8])}...\n{r.stderr[-1500:]}")
    return r.stdout


def parse_removals(spec, words):
    out = []
    for part in filter(None, (p.strip() for p in (spec or "").split(","))):
        m = re.fullmatch(r"w(\d+)\s*-\s*w(\d+)", part)
        if m:
            i, j = int(m.group(1)), int(m.group(2))
            out.append((words[i]["start"] - 0.02, words[j]["end"] + 0.02))
        else:
            s, e = (float(v) for v in part.split("-"))
            out.append((s, e))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", required=True)
    ap.add_argument("--src", help="defaults to the file transcribe.py used")
    ap.add_argument("--max-gap", type=float, default=0.30, help="pauses longer than this get cut")
    ap.add_argument("--pad-in", type=float, default=0.06)
    ap.add_argument("--pad-out", type=float, default=0.10)
    ap.add_argument("--remove", default="", help="flubs/retakes: w10-w15 (word indices) or 31.2-32.0 (seconds)")
    ap.add_argument("--fps", type=int, default=30)
    a = ap.parse_args()
    tr = json.load(open(os.path.join(a.work, "transcript.json")))
    src = a.src or tr["source"]
    fps, words, dur = a.fps, tr["words"], tr["duration"]
    spf = ASR // fps  # audio samples per video frame (1600 at 30 fps)

    # 1. Normalize once: portrait 1080x1920, constant frame rate, plus a 48 kHz stereo WAV.
    norm, wav = os.path.join(a.work, "norm.mp4"), os.path.join(a.work, "norm.wav")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", src,
        "-map", "0:v:0", "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={fps},format=yuv420p",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-g", str(fps // 2), "-an", norm,
        "-map", "0:a:0", "-af", "aresample=async=1:first_pts=0", "-ac", "2", "-ar", str(ASR), "-c:a", "pcm_s16le", wav])
    nframes = int(sh(["ffprobe", "-v", "error", "-count_packets", "-select_streams", "v:0", "-show_entries",
                      "stream=nb_read_packets", "-of", "csv=p=0", norm]).strip())
    w = wave.open(wav)
    audio = np.frombuffer(w.readframes(w.getnframes()), np.int16).reshape(-1, 2).astype(np.float32)
    need = nframes * spf
    audio = np.pad(audio, ((0, max(0, need - len(audio))), (0, 0)))[:need]

    # 2. Keep regions = speech + words, padded; short pauses stay, long ones go; flubs removed.
    keep = [[s - a.pad_in, e + a.pad_out] for s, e in tr["speech"]]
    keep += [[x["start"] - a.pad_in, x["end"] + a.pad_out] for x in words]
    keep.sort()
    merged = []
    for s, e in keep:
        if merged and s - merged[-1][1] <= a.max_gap:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    for rs, re_ in parse_removals(a.remove, words):
        nxt = []
        for s, e in merged:
            if re_ <= s or rs >= e:
                nxt.append([s, e])
            else:
                if rs > s: nxt.append([s, rs])
                if re_ < e: nxt.append([re_, e])
        merged = nxt
    gone = parse_removals(a.remove, words)
    mids = [(x["start"] + x["end"]) / 2 for x in words if not any(rs <= (x["start"] + x["end"]) / 2 <= re_ for rs, re_ in gone)]
    # drop short leftovers with no kept word in them (breaths, clicks, the first sound of a removed retake)
    merged = [[s, e] for s, e in merged if e - s >= 0.6 or any(s <= m <= e for m in mids)]
    segs = []  # frame-snapped [f0, f1)
    for s, e in merged:
        f0, f1 = max(0, math.floor(s * fps)), min(nframes, math.ceil(e * fps))
        if segs and f0 <= segs[-1][1]:
            segs[-1][1] = max(segs[-1][1], f1)
        elif f1 - f0 >= 4:
            segs.append([f0, f1])

    # 3. Video: one encode per segment (memory-safe), exact frame counts, then stream-copy concat.
    lst = os.path.join(a.work, "segs.txt")
    with open(lst, "w") as fh:
        for k, (f0, f1) in enumerate(segs):
            p = os.path.join(a.work, f"seg_{k:03d}.mp4")
            sh(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{max(0.0, (f0 - 0.1) / fps):.6f}", "-i", norm, "-frames:v", str(f1 - f0),
                "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p", "-r", str(fps), p])
            fh.write(f"file '{p}'\n")
    vcut = os.path.join(a.work, "cut_video.mp4")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", vcut])

    # 4. Audio: slice by sample index, 8 ms fades at every join so cuts don't click.
    fade = int(0.008 * ASR)
    parts = []
    for f0, f1 in segs:
        p = audio[f0 * spf : f1 * spf].copy()
        ramp = np.linspace(0, 1, fade)[:, None]
        p[:fade] *= ramp; p[-fade:] *= ramp[::-1]
        parts.append(p)
    cut_audio = np.concatenate(parts)
    cwav = os.path.join(a.work, "cut_audio.wav")
    with wave.open(cwav, "wb") as o:
        o.setnchannels(2); o.setsampwidth(2); o.setframerate(ASR)
        o.writeframes(np.clip(cut_audio, -32768, 32767).astype(np.int16).tobytes())
    out = os.path.join(a.work, "cut.mp4")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", vcut, "-i", cwav, "-map", "0:v", "-map", "1:a",
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out])
    for k in range(len(segs)):
        os.remove(os.path.join(a.work, f"seg_{k:03d}.mp4"))

    # 5. Re-time words onto the new timeline.
    offs, acc = [], 0
    for f0, f1 in segs:
        offs.append(acc); acc += f1 - f0
    new_dur = acc / fps

    def remap(t):
        for (f0, f1), off in zip(segs, offs):
            s, e = f0 / fps, f1 / fps
            if t < s:
                return off / fps  # inside a removed gap: snap to the next kept frame
            if t <= e:
                return off / fps + (t - s)
        return new_dur

    def removed(x):
        mid = (x["start"] + x["end"]) / 2
        return not any(f0 / fps <= mid <= f1 / fps for f0, f1 in segs)

    kept = []
    for x in words:
        if removed(x):
            continue
        s, e = remap(x["start"]), remap(x["end"])
        kept.append({"i": x["i"], "w": x["w"], "start": round(s, 3), "end": round(max(e, s + 0.05), 3)})
    json.dump(kept, open(os.path.join(a.work, "words_cut.json"), "w"), indent=0)
    cuts = [round(off / fps, 3) for (f0, f1), (pf0, pf1), off in zip(segs[1:], segs, offs[1:]) if f0 - pf1 >= 3]
    json.dump({"duration": round(new_dur, 3), "fps": fps, "cuts": cuts,
               "segments": [[f0 / fps, f1 / fps] for f0, f1 in segs]}, open(os.path.join(a.work, "cuts.json"), "w"), indent=1)

    lines = [f"# cut timeline {new_dur:.2f}s (from {nframes / fps:.2f}s) | {len(segs)} segments | {len(cuts)} jump cuts",
             "# [start-end] index:word  (indices match transcript.txt; use w12 or seconds in storyboard.json)"]
    cur = []
    for k, x in enumerate(kept):
        cur.append(x)
        gap = kept[k + 1]["start"] - x["end"] if k + 1 < len(kept) else 9
        if gap >= 0.25 or len(cur) >= 10 or (x["w"][-1] in ".?!" and len(cur) >= 3):
            lines.append(f"[{cur[0]['start']:6.2f}-{cur[-1]['end']:6.2f}] " + " ".join(f"{c['i']}:{c['w']}" for c in cur))
            cur = []
    open(os.path.join(a.work, "transcript_cut.txt"), "w").write("\n".join(lines) + "\n")
    got = int(sh(["ffprobe", "-v", "error", "-count_packets", "-select_streams", "v:0", "-show_entries",
                  "stream=nb_read_packets", "-of", "csv=p=0", vcut]).strip())
    print(f"cut: {nframes / fps:.2f}s -> {new_dur:.2f}s, removed {nframes / fps - new_dur:.2f}s across {len(segs)} segments; "
          f"frames {got}/{acc} {'OK' if got == acc else 'MISMATCH'}; audio {len(cut_audio) / ASR:.3f}s")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
