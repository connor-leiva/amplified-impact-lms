#!/usr/bin/env python3
"""Turn WORKDIR/storyboard.json into a HyperFrames project (WORKDIR/project) plus sound cues.

Usage: python3 build.py --work WORKDIR

Reads storyboard.json (you write it), words_cut.json + cuts.json (cut.py), layout.json (analyze.py).
Writes project/index.html (+ assets), cues.json (sound effects), audio_plan.json (music) and
snapshot_times.txt (frames worth checking). Prints warnings for anything that will look wrong.
Schema and examples: references/storyboard.md. Looks: references/styles.md.
"""
import argparse, glob, html, json, os, re, shutil, subprocess, sys

W, H = 1080, 1920
SAFE_BOTTOM = 1545
RK = os.environ.get("REELKIT_HOME", "/home/claude/.reelkit")
NM = os.path.join(RK, "node", "node_modules")
STOP = set("""a an the and or but so to of in on at for with by from as is are was were be been being am i i'm im it it's
its this that these those my our your their his her we you they me us them do does did just very really what how why when
where who which if then than there here have has had will would can could should not no up out about into over after before
like also because all any some more most one get got go going gonna wanna i've i'll we're you're that's there's let's""".split())
PANEL = {"icons", "sticker", "versus", "checklist", "list", "flow", "endcard"}
ICON_ALIAS = {"home": "house", "email": "mail", "envelope": "mail", "robot": "bot", "ai": "bot", "gear": "settings",
              "cog": "settings", "team": "users", "people": "users", "person": "user", "calendar": "calendar-days",
              "money": "circle-dollar-sign", "dollar": "circle-dollar-sign", "chart": "chart-line", "growth": "trending-up",
              "checklist": "list-checks", "list": "list-checks", "task": "clipboard-list", "clipboard": "clipboard-list",
              "idea": "lightbulb", "time": "clock", "chat": "message-circle", "message": "message-circle",
              "doc": "file-text", "document": "file-text", "magic": "wand-sparkles", "review": "user-check",
              "done": "circle-check", "key": "key-round", "building": "building-2", "write": "pen-line", "pen": "pen-line",
              "bolt": "zap", "sparkle": "sparkles", "location": "map-pin", "warning": "triangle-alert", "no": "x"}


def norm(w):
    return re.sub(r"[^a-z0-9']", "", str(w).lower().replace("\u2019", "'"))


def esc(s):
    return html.escape(str(s), quote=True)


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[k:k + 2], 16) for k in (0, 2, 4))


def rgba(h, a):
    return "rgba(%d,%d,%d,%s)" % (*rgb(h), a)


def mix(h1, h2, t):
    a, b = rgb(h1), rgb(h2)
    return "#%02X%02X%02X" % tuple(round(x + (y - x) * t) for x, y in zip(a, b))


class TL:
    def __init__(self):
        self.out = []

    def _p(self, p, d=None, ease=None):
        p = {k: v for k, v in p.items()}
        if d is not None:
            p["duration"] = round(max(0.01, d), 3)
        if ease:
            p["ease"] = ease
        return json.dumps(p)

    def set(self, sel, t, **p):
        self.out.append(f"tl.set({json.dumps(sel)},{self._p(p)},{max(0.0, t):.3f});")

    def to(self, sel, t, d, ease="power2.out", **p):
        self.out.append(f"tl.to({json.dumps(sel)},{self._p(p, d, ease)},{max(0.0, t):.3f});")

    def fromto(self, sel, t, d, frm, ease="power3.out", **p):
        self.out.append(f"tl.fromTo({json.dumps(sel)},{json.dumps(frm)},{self._p(p, d, ease)},{max(0.0, t):.3f});")


class Reel:
    def __init__(self, work):
        self.work = work
        J = lambda n: json.load(open(os.path.join(work, n)))
        self.sb, self.words, self.L, self.C = J("storyboard.json"), J("words_cut.json"), J("layout.json"), J("cuts.json")
        self.dur = float(self.C["duration"])
        self.L.update(self.sb.get("layout", {}))  # manual framing overrides (text_top, panel_top, glide, face_center)
        self.byi = {w["i"]: w for w in self.words}
        self.style = self.sb.get("style", "editorial")
        if self.style not in ("editorial", "creator"):
            sys.exit("style must be 'editorial' or 'creator'")
        b = self.sb.get("brand", {})
        acc = b.get("accent") or self.L["palette"]["accent"]
        self.col = {"accent": acc, "paper": b.get("paper") or mix("#F4F1EB", acc, 0.035),
                    "ink": b.get("ink", "#22201C"), "neg": b.get("neg", "#8C2B3A")}
        self.handle = b.get("handle", "")
        self.level = self.sb.get("sfx", "subtle" if self.style == "editorial" else "punchy")
        self.tl, self.cues, self.snaps, self.warn, self.n = TL(), [], [], [], 0
        self.layer = {k: [] for k in ("vis", "text", "label", "top", "page", "pagetext", "over")}
        self.fixes = {int(str(k).lstrip("w")): v for k, v in self.sb.get("fix", {}).items()}
        self.big = {norm(x) for x in self.sb.get("big", [])}
        self.neg = {norm(x) for x in self.sb.get("neg", [])}
        self.css_extra = []
        try:
            self.emoji_ok = "Noto Color Emoji" in subprocess.run(["fc-list"], capture_output=True, text=True).stdout
        except Exception:
            self.emoji_ok = False

    # ---------- helpers ----------
    def uid(self, p="e"):
        self.n += 1
        return f"{p}{self.n}"

    def T(self, v, default=None):
        if v is None or v == "":
            return default
        if isinstance(v, (int, float)):
            return float(v)
        m = re.fullmatch(r"w(\d+)(\.end)?", str(v).strip())
        if m:
            i = int(m.group(1))
            if i not in self.byi:
                near = min(self.byi, key=lambda k: abs(k - i))
                self.warn.append(f"w{i} was cut from the video; using w{near} instead")
                i = near
            return self.byi[i]["end" if m.group(2) else "start"]
        return float(v)

    def sfx(self, t, name, gain=0.0, only=None):
        if self.level == "off" or (only and self.level != only):
            return
        if 0 <= t < self.dur:
            self.cues.append({"t": round(t, 3), "sfx": name, "gain_db": gain})

    def icon(self, name, cls=""):
        d = os.path.join(NM, "lucide-static", "icons")
        name = re.sub(r"[^a-z0-9-]", "", str(name or "sparkles").lower().replace(" ", "-")) or "sparkles"
        cands = [name, ICON_ALIAS.get(name, ""), *sorted(os.path.basename(p)[:-4] for p in glob.glob(f"{d}/{name}*.svg"))[:1], "sparkles"]
        for c in cands:
            p = os.path.join(d, f"{c}.svg")
            if c and os.path.exists(p):
                svg = open(p).read()
                svg = re.sub(r"<!--.*?-->", "", svg, flags=re.S)
                svg = re.sub(r'\s(class|width|height)="[^"]*"', "", svg, count=3)
                return svg.replace("<svg", f'<svg class="ic {cls}"', 1)
        return ""

    def disp(self, s):
        s = re.sub(r"^[^\w$%&+']+|[^\w%&+']+$", "", str(s))
        return s.lower() if self.style == "editorial" else s.upper()

    def spread(self, items, s, e):
        n = len(items)
        out = []
        for k, it in enumerate(items):
            t = self.T(it.get("at")) if isinstance(it, dict) else None
            out.append(t if t is not None else s + 0.3 + (min(e - s, 4.0) * 0.55) * k / max(1, n))
        return out

    # ---------- timeline structure ----------
    def resolve(self):
        sb = self.sb
        self.hook_end = 0.0
        if sb.get("hook"):
            hk = sb["hook"]
            self.hook_end = self.T(hk.get("until"), None) or self.T(hk.get("end"), 2.4)
        self.sections = sorted([(s["label"], self.T(s.get("at"), 0.0)) for s in sb.get("sections", [])], key=lambda x: x[1])
        self.beats = []
        for b in sb.get("beats", []):
            b = dict(b)
            b["s"] = self.T(b.get("start"), None)
            if b["s"] is None:
                self.warn.append(f"beat {b.get('type')} has no start; skipped"); continue
            b["e"] = min(self.dur, self.T(b.get("end"), b["s"] + 3.0))
            if b["e"] - b["s"] < 1.0:
                self.warn.append(f"{b['type']} at {b['s']:.2f}s is only {b['e'] - b['s']:.2f}s long (aim for 1.5s+)")
            self.beats.append(b)
        self.beats.sort(key=lambda b: b["s"])
        for a, b in zip(self.beats, self.beats[1:]):
            if b["s"] < a["e"] - 0.05:
                self.warn.append(f"{a['type']} ({a['s']:.1f}-{a['e']:.1f}s) overlaps {b['type']} ({b['s']:.1f}s): end the first earlier")
        ed = self.style == "editorial"
        spans = sorted((b["s"], b["e"]) for b in self.beats if ed and b["type"] in PANEL)
        self.panels = []
        for s, e in spans:  # adjacent panels stay up instead of dropping and rising again
            if self.panels and s - self.panels[-1][1] < 0.9:
                self.panels[-1][1] = max(self.panels[-1][1], e)
            else:
                self.panels.append([s, e])
        self.pages = [(b["s"], b["e"]) for b in self.beats if ed and b["type"] == "count"]

    def surface(self, t):
        if any(s - 0.15 <= t < e - 0.3 for s, e in self.pages):
            return "page"
        if any(s - 0.1 <= t < e - 0.1 for s, e in self.panels):
            return "paper"
        return "video"

    def floor_for(self, t):
        for s, e in self.pages:
            if s - 0.15 <= t < e:
                return s + 0.25
        for s, e in self.panels:
            if s - 0.1 <= t < e:
                return s + 0.3
        return 0.0

    def groups(self):
        maxw = int(self.sb.get("max_words", 5 if self.style == "editorial" else 3))
        sect = lambda t: sum(1 for _, a in self.sections if a <= t + 1e-6)
        vis = []
        for w in self.words:
            txt = self.fixes.get(w["i"], w["w"])
            if not self.disp(txt) or w["start"] < self.hook_end - 0.02:
                continue
            vis.append(dict(w, txt=txt))
        out, cur = [], []
        for w in vis:
            if cur:
                p = cur[-1]
                if (len(cur) >= maxw or w["start"] - p["end"] > 0.30 or w["start"] - cur[0]["start"] > 2.6
                        or (p["txt"][-1:] in ".?!:;" ) or (p["txt"][-1:] == "," and len(cur) >= 2)
                        or self.surface(w["start"]) != self.surface(cur[0]["start"]) or sect(w["start"]) != sect(cur[0]["start"])):
                    out.append(cur); cur = []
            cur.append(w)
        if cur:
            out.append(cur)
        ends = []
        for k, g in enumerate(out):
            e = min(out[k + 1][0]["start"] - 0.05 if k + 1 < len(out) else self.dur, g[-1]["end"] + 0.8, self.dur - 0.02)
            surf = self.surface(g[0]["start"])
            for s, pe in (self.pages if surf == "page" else self.panels if surf == "paper" else []):
                if s - 0.2 <= g[0]["start"] < pe:
                    e = min(e, pe - (0.38 if surf == "page" else 0.14))
            ends.append(e)
        return out, ends

    def size_class(self, g, w):
        n = norm(w["txt"])
        if self.big:
            if n in self.big:
                return "b"
        elif len(g) >= 2:
            cands = [x for x in g if norm(x["txt"]) not in STOP and len(norm(x["txt"])) >= 4]
            if cands and w is max(cands, key=lambda x: len(norm(x["txt"]))):
                return "b"
        return "s" if n in STOP else "m"

    # ---------- shared motion ----------
    def shake(self, t, amp=14):
        for k, (x, y) in enumerate([(1, -.6), (-.8, .5), (.5, .4), (-.3, -.3), (.15, .1), (0, 0)]):
            self.tl.to("#shake", t + k * 0.035, 0.035, "none", x=round(x * amp, 1), y=round(y * amp, 1))

    def flash(self, t):
        self.tl.set("#flash", t, opacity=0.8)
        self.tl.to("#flash", t + 0.03, 0.3, "power2.out", opacity=0)

    def draw(self, sel, t, d=0.35):
        self.tl.to(sel, t, d, "power1.inOut", strokeDashoffset=0)

    def camera(self):
        z = 1.045 if self.style == "editorial" else 1.07
        self.tl.set("#punch", 0, scale=1)
        on = False
        for c in self.C.get("cuts", []):
            on = not on
            self.tl.set("#punch", c, scale=z if on else 1)
        if self.style == "editorial":
            G, off = self.L["glide"], H - self.L["panel_top"] + 60
            self.tl.set("#paper", 0, y=off)
            for s, e in self.panels:
                self.tl.to("#paper", s - 0.1, 0.5, "power3.out", y=0)
                self.tl.to("#cam", s - 0.1, 0.55, "power3.inOut", y=-G)
                self.tl.to("#paper", e - 0.1, 0.42, "power2.in", y=off)
                self.tl.to("#cam", e - 0.1, 0.5, "power3.inOut", y=0)
                self.sfx(s - 0.1, "paper", -3)

    # ---------- text ----------
    def text(self):
        groups, ends = self.groups()
        ed = self.style == "editorial"
        if self.sb.get("hook"):
            hw = [{"txt": t, "start": 0.08 + k * 0.11, "end": 0.2 + k * 0.11, "i": -1}
                  for k, t in enumerate(str(self.sb["hook"].get("text", "")).split())]
            if ed and hw:
                self.group_ed(hw, self.hook_end - 0.08, 0, hook=True)
            elif hw:
                self.hook_cr(hw)
        for k, (g, e) in enumerate(zip(groups, ends)):
            (self.group_ed if ed else self.group_cr)(g, e, k)
        self.snaps += [ (g[-1]["start"] + e) / 2 for g, e in list(zip(groups, ends))[1::max(1, len(groups) // 4)] ][:4]

    def group_ed(self, g, end, k, hook=False):
        surf = "video" if hook else self.surface(g[0]["start"])
        gid = self.uid("g")
        align = {"video": "lci", "paper": "li", "page": "c"}[surf]
        al = align[k % len(align)]
        top = {"video": self.L["text_top"] + 92, "paper": self.L["panel_top"] + 128, "page": 300}[surf]
        floor = 0.0 if hook else self.floor_for(g[0]["start"])
        spans, last_neg = [], None
        for j, w in enumerate(g):
            cls = self.size_class(g, w)
            neg = norm(w["txt"]) in self.neg
            wid = f"{gid}w{j}"
            spans.append(f'<span class="w {cls}{" k" if cls == "b" else ""}{" n" if neg else ""}" id="{wid}">{esc(self.disp(w["txt"]))}</span>')
            t = max(w["start"] - 0.06, floor)
            self.tl.fromto("#" + wid, t, 0.2, {"opacity": 0, "y": 26}, "power3.out", opacity=1, y=0)
            if neg:
                last_neg = (j, t)
        if last_neg and surf != "video":
            xid = gid + "x"
            spans.insert(last_neg[0] + 1, f'<span class="xb" id="{xid}">{self.icon("x")}</span>')
            self.tl.fromto("#" + xid, last_neg[1] + 0.12, 0.3, {"opacity": 0, "scale": 0.3}, "back.out(2)", opacity=1, scale=1)
            self.sfx(last_neg[1] + 0.12, "buzz", -6)
        layer = "pagetext" if surf == "page" else "text"
        self.layer[layer].append(f'<div class="kg on-{surf} a{al}" id="{gid}" style="top:{top}px">{"".join(spans)}</div>')
        self.tl.to("#" + gid, end, 0.14, "power1.in", opacity=0)
        if hook:
            self.sfx(0.05, "whoosh_soft", -2)
            self.snaps.append(min(self.hook_end - 0.2, 1.2))

    def group_cr(self, g, end, k):
        gid = self.uid("g")
        colors = ["#FFE14D", "#7BE495", "#FF8FC4"]
        box = colors[k % 3]
        top = max(self.L["text_top"] + 330, 1290)
        if any(b["type"] == "count" and b["s"] - 0.1 <= g[0]["start"] < b["e"] for b in self.beats):
            top = 1425  # keep captions clear of the big number and grid
        spans = []
        for j, w in enumerate(g):
            n = norm(w["txt"])
            neg, big = n in self.neg, self.size_class(g, w) == "b" and len(g) > 1
            wid = f"{gid}w{j}"
            spans.append(f'<span class="cw{" big" if big else ""}" id="{wid}"><b class="hl" id="{wid}h" '
                         f'style="background:{"#FF4A4A" if neg else box}"></b><span class="t">{esc(self.disp(w["txt"]))}</span></span>')
            nxt = g[j + 1]["start"] if j + 1 < len(g) else end
            self.tl.set(f"#{wid}h", w["start"] - 0.03, opacity=1)
            if nxt - 0.03 > w["start"]:
                self.tl.set(f"#{wid}h", nxt - 0.03, opacity=0)
        self.layer["text"].append(f'<div class="cg" id="{gid}" style="top:{top}px">{"".join(spans)}</div>')
        self.tl.fromto("#" + gid, g[0]["start"] - 0.06, 0.14, {"opacity": 0, "scale": 0.86}, "back.out(2)", opacity=1, scale=1)
        self.tl.to("#" + gid, end, 0.1, "power1.in", opacity=0)

    def hook_cr(self, hw):
        hid = self.uid("hook")
        top = self.L["text_top"] - 10
        words = " ".join(self.disp(w["txt"]) for w in hw)
        self.layer["over"].append(f'<div class="stk hookstk" id="{hid}" style="top:{top}px">{esc(words)}</div>')
        self.tl.fromto("#" + hid, 0.05, 0.35, {"opacity": 0, "scale": 1.7, "rotation": -9}, "back.out(1.6)", opacity=1, scale=1, rotation=-3)
        self.tl.to("#" + hid, self.hook_end - 0.12, 0.15, "power1.in", opacity=0)
        self.shake(0.32, 16)
        self.sfx(0.3, "impact", -2)
        self.snaps.append(min(self.hook_end - 0.2, 1.2))

    # ---------- labels / series ----------
    def labels(self):
        ed = self.style == "editorial"
        for idx, (lab, at) in enumerate(self.sections):
            end = self.sections[idx + 1][1] if idx + 1 < len(self.sections) else self.dur
            lid = self.uid("lb")
            if ed:
                self.layer["label"].append(f'<div class="lbl" id="{lid}" style="top:{self.L["text_top"]}px">{esc(lab.lower())}</div>')
                self.tl.fromto("#" + lid, at + 0.02, 0.35, {"opacity": 0, "x": -18}, "power3.out", opacity=1, x=0)
                dy = self.L["panel_top"] + 40 - self.L["text_top"]
                for ps, pe in self.panels:
                    if pe <= at or ps >= end:
                        continue
                    if ps <= at:
                        self.tl.set("#" + lid, at, y=dy)
                    else:
                        self.tl.to("#" + lid, ps - 0.1, 0.5, "power3.out", y=dy)
                    if pe < end:
                        self.tl.to("#" + lid, pe - 0.1, 0.45, "power3.inOut", y=0)
                if end < self.dur:
                    self.tl.to("#" + lid, end - 0.08, 0.16, "power1.in", opacity=0)
            else:
                colors = ["#FFE14D", "#FF8FC4", "#7BE495", "#FFFFFF"]
                left = 90 if idx % 2 == 0 else 470
                rot = -4 if idx % 2 == 0 else 3
                self.layer["label"].append(f'<div class="stk" id="{lid}" style="top:{self.L["text_top"] - 10}px;left:{left}px;'
                                           f'background:{colors[idx % 4]}">{esc(lab.upper())}</div>')
                self.tl.fromto("#" + lid, at + 0.02, 0.3, {"opacity": 0, "scale": 1.6, "rotation": rot * 3}, "back.out(1.8)",
                               opacity=1, scale=1, rotation=rot)
                self.tl.to("#" + lid, min(end, at + 2.3) - 0.15, 0.15, "power1.in", opacity=0)
                self.sfx(at, "whoosh", -6)
        if self.sb.get("series"):
            sid = "series"
            self.layer["top"].append(f'<div class="series {self.style}" id="{sid}">{esc(self.sb["series"])}</div>')
            self.tl.fromto("#" + sid, 0.35, 0.4, {"opacity": 0, "y": -10}, "power3.out", opacity=1, y=0)

    # ---------- beats: editorial (paper panels) ----------
    def visbox(self):
        top = self.L["panel_top"] + 330
        return top, max(150, SAFE_BOTTOM - top)

    def vis_wrap(self, b, inner, extra_cls="", style=""):
        top, h = self.visbox()
        bid = self.uid("b")
        self.layer["vis"].append(f'<div class="vis {extra_cls}" id="{bid}" style="top:{top}px;height:{h}px;{style}">{inner}</div>')
        self.tl.to("#" + bid, b["e"] - 0.32, 0.22, "power1.in", opacity=0)
        self.snaps.append(b["s"] + 0.68 * (b["e"] - b["s"]))
        return bid

    def ed_icons(self, b):
        items = b.get("items") or [b]
        items = items[:4]
        top, h = self.visbox()
        cs = int(max(84, min(210 if len(items) <= 2 else 170, h - 80, 860 / len(items) - 50)))
        ats = self.spread(items, b["s"], b["e"])
        bid = self.uid("ic")
        parts = []
        for k, (it, t) in enumerate(zip(items, ats)):
            iid = f"{bid}i{k}"
            parts.append(f'<div class="it" id="{iid}"><div class="dot" style="width:{cs}px;height:{cs}px">{self.icon(it.get("icon"))}</div>'
                         f'<div class="lab">{esc(str(it.get("label", "")).lower())}</div></div>')
            self.tl.fromto("#" + iid, max(t, b["s"] + 0.3), 0.45, {"opacity": 0, "y": 30, "scale": 0.8}, "back.out(1.7)", opacity=1, y=0, scale=1)
            self.sfx(max(t, b["s"] + 0.3), "pop", -6)
        self.vis_wrap(b, "".join(parts), "row")

    def ed_versus(self, b):
        L, R = b.get("left", {}), b.get("right", {})
        rev = self.T(b.get("reveal_at"), b["s"] + 0.45 * (b["e"] - b["s"]))
        top, h = self.visbox()
        cs = int(max(84, min(150, h - 80)))
        bid = self.uid("vs")
        side = lambda k, it, cls: (f'<div class="it vs-{k}" id="{bid}{k}"><div class="dot {cls}" id="{bid}{k}d" style="width:{cs}px;height:{cs}px">'
                                   f'{self.icon(it.get("icon"))}</div><div class="lab" id="{bid}{k}l">{esc(str(it.get("label", "")).lower())}</div>'
                                   f'<span class="badge {"bx" if k == "L" else "bk"}" id="{bid}{k}b">{self.icon("x" if k == "L" else "check")}</span></div>')
        inner = side("L", L, "muted") + f'<div class="vsmid" id="{bid}m">{self.icon("arrow-right")}</div>' + side("R", R, "")
        self.tl.fromto(f"#{bid}L", b["s"] + 0.3, 0.45, {"opacity": 0, "y": 26}, "power3.out", opacity=1, y=0)
        self.tl.fromto(f"#{bid}m", b["s"] + 0.5, 0.35, {"opacity": 0, "x": -14}, "power3.out", opacity=1, x=0)
        self.tl.fromto(f"#{bid}R", rev, 0.5, {"opacity": 0, "y": 26, "scale": 0.86}, "back.out(1.6)", opacity=1, y=0, scale=1)
        self.tl.fromto(f"#{bid}Lb", rev + 0.15, 0.3, {"opacity": 0, "scale": 0.3}, "back.out(2)", opacity=1, scale=1)
        self.tl.to(f"#{bid}Ld", rev + 0.15, 0.3, "power1.out", opacity=0.45)
        self.tl.to(f"#{bid}Ll", rev + 0.15, 0.3, "power1.out", opacity=0.45)
        self.tl.fromto(f"#{bid}Rb", rev + 0.4, 0.3, {"opacity": 0, "scale": 0.3}, "back.out(2)", opacity=1, scale=1)
        self.sfx(rev, "whoosh_soft", -4); self.sfx(rev + 0.4, "tick", -4)
        self.vis_wrap(b, inner, "row")

    def ed_rows(self, b, marks):
        items = (b.get("items") or [])[:5]
        top, h = self.visbox()
        fs = int(max(30, min(46, h / max(1, len(items)) * 0.52)))
        ats = self.spread(items, b["s"], b["e"])
        bid = self.uid("rw")
        parts = []
        for k, (it, t) in enumerate(zip(items, ats)):
            it = it if isinstance(it, dict) else {"text": it}
            mk = it.get("mark", "check") if marks else "check"
            rid = f"{bid}r{k}"
            parts.append(f'<div class="rowi" id="{rid}" style="font-size:{fs}px"><span class="badge {"bx" if mk == "x" else "bk"} inl">'
                         f'{self.icon("x" if mk == "x" else "check")}</span><span>{esc(str(it.get("text", "")).lower())}</span></div>')
            self.tl.fromto("#" + rid, t, 0.4, {"opacity": 0, "x": -24}, "power3.out", opacity=1, x=0)
            if mk == "x":
                for j, x in enumerate([-10, 9, -6, 4, 0]):
                    self.tl.to("#" + rid, t + 0.42 + j * 0.05, 0.05, "none", x=x)
                self.sfx(t + 0.42, "buzz", -6)
            else:
                self.sfx(t, "tick", -4)
        if b.get("stamp"):
            st = self.T(b.get("stamp_at"), b["e"] - 1.1)
            sid = bid + "s"
            parts.append(f'<div class="stamp" id="{sid}">{esc(str(b["stamp"]).lower())}</div>')
            self.tl.fromto("#" + sid, st, 0.32, {"opacity": 0, "scale": 1.6, "rotation": -14}, "power4.out", opacity=1, scale=1, rotation=-7)
            self.sfx(st, "stamp", -3)
            self.snaps.append(st + 0.4)
        self.vis_wrap(b, "".join(parts), "col")

    def ed_flow(self, b):
        steps = (b.get("steps") or b.get("items") or [])[:4]
        top, h = self.visbox()
        cs = int(max(76, min(120, h - 90)))
        ats = self.spread(steps, b["s"], b["e"])
        bid = self.uid("fl")
        parts = []
        for k, (it, t) in enumerate(zip(steps, ats)):
            if k:
                cid = f"{bid}c{k}"
                parts.append(f'<div class="conn" id="{cid}" style="margin-top:{cs // 2 - 2}px"></div>')
                self.tl.fromto("#" + cid, t - 0.28, 0.3, {"scaleX": 0}, "power2.out", scaleX=1)
            sid = f"{bid}s{k}"
            parts.append(f'<div class="it st" id="{sid}"><div class="dot" style="width:{cs}px;height:{cs}px">{self.icon(it.get("icon"))}</div>'
                         f'<div class="lab sm">{esc(str(it.get("label", "")).lower())}</div></div>')
            self.tl.fromto("#" + sid, t, 0.42, {"opacity": 0, "scale": 0.7}, "back.out(1.8)", opacity=1, scale=1)
            self.sfx(t, "pop", -7)
        self.vis_wrap(b, "".join(parts), "row flow")

    def ed_endcard(self, b):
        press = max(b["s"] + 0.9, self.T(b.get("press_at"), b["s"] + 0.45 * (b["e"] - b["s"])))
        bid = self.uid("ec")
        handle = b.get("handle", self.handle)
        inner = (f'<div class="handle" id="{bid}h">{esc(handle)}</div>' if handle else "") + \
                f'<div class="follow" id="{bid}f"><span id="{bid}f1">{esc(b.get("button", "follow"))}</span>' \
                f'<span id="{bid}f2" class="f2">{esc(b.get("pressed", "following"))} {self.icon("check")}</span></div>' + \
                (f'<div class="sub" id="{bid}s">{esc(str(b["sub"]).lower())}</div>' if b.get("sub") else "")
        if handle:
            self.tl.fromto(f"#{bid}h", b["s"] + 0.3, 0.4, {"opacity": 0, "y": 16}, "power3.out", opacity=1, y=0)
        self.tl.fromto(f"#{bid}f", b["s"] + 0.4, 0.45, {"opacity": 0, "scale": 0.8}, "back.out(1.8)", opacity=1, scale=1)
        self.tl.to(f"#{bid}f", press, 0.08, "power2.in", scale=0.9)
        self.tl.to(f"#{bid}f", press + 0.08, 0.3, "back.out(3)", scale=1)
        self.tl.to(f"#{bid}f", press + 0.05, 0.15, "power1.out", backgroundColor=self.col["ink"])
        self.tl.to(f"#{bid}f1", press + 0.05, 0.1, "none", opacity=0)
        self.tl.fromto(f"#{bid}f2", press + 0.05, 0.12, {"opacity": 0}, "none", opacity=1)
        if b.get("sub"):
            self.tl.fromto(f"#{bid}s", press + 0.4, 0.4, {"opacity": 0, "y": 12}, "power3.out", opacity=1, y=0)
        self.sfx(press, "tap", -2); self.sfx(press + 0.1, "ding", -4)
        self.snaps.append(press + 0.6)
        self.vis_wrap(b, inner, "col center")

    def ed_count(self, b):
        n = int(b.get("to", 30))
        bid = self.uid("pg")
        vals = sorted({round(n * j / min(n, 60)) for j in range(0, min(n, 60) + 1)})
        t0, D = b["s"] + 0.45, min(1.8, max(0.8, (b["e"] - b["s"]) * 0.45))
        times = [t0 + D * (1 - (1 - v / n) ** 2) for v in vals]
        nums = "".join(f'<span id="{bid}n{k}">{v}{esc(b.get("suffix", ""))}</span>' for k, v in enumerate(vals))
        cells = min(n, 60) if b.get("grid", True) else 0
        cols = 6 if 20 <= cells <= 36 else min(10, max(1, cells))
        cw = int(min(92, 860 / max(1, cols) - 14))
        grid = "".join(f'<i id="{bid}c{k}" style="width:{cw}px;height:{cw}px"></i>' for k in range(cells))
        self.layer["page"].append(f'<div class="page" id="{bid}"><div class="num" id="{bid}num">{nums}</div>'
                                  f'<div class="cells" style="grid-template-columns:repeat({cols},{cw}px)">{grid}</div></div>')
        self.tl.set("#" + bid, 0, y=H)
        self.tl.to("#" + bid, b["s"] - 0.15, 0.45, "power3.out", y=0)
        self.tl.to("#" + bid, b["e"] - 0.35, 0.4, "power2.in", y=-H)
        self.tl.set(f"#{bid}n0", b["s"] - 0.15, opacity=1)
        for k in range(1, len(vals)):
            self.tl.set(f"#{bid}n{k - 1}", times[k], opacity=0)
            self.tl.set(f"#{bid}n{k}", times[k], opacity=1)
        for k in range(cells):
            v = (k + 1) * n / cells
            idx = min(range(len(vals)), key=lambda j: abs(vals[j] - v))
            self.tl.set(f"#{bid}c{k}", times[idx], backgroundColor=self.col["accent"])
        self.sfx(b["s"] - 0.15, "paper", -2)
        for k in range(1, len(vals), max(1, len(vals) // 8)):
            self.sfx(times[k], "count_tick", -8)
        self.sfx(times[-1] + 0.02, "ding", -3)
        self.snaps.append(min(times[-1] + 0.3, b["e"] - 0.45))

    def ed_aside(self, b):
        aid = self.uid("as")
        surf = self.surface(b["s"])
        top = (self.L["panel_top"] + 300) if surf == "paper" else min(SAFE_BOTTOM - 70, self.L["text_top"] + 92 + 330)
        self.layer["text"].append(f'<div class="aside on-{surf}" id="{aid}" style="top:{top}px">{esc(b.get("text", ""))}</div>')
        self.tl.fromto("#" + aid, b["s"], 0.4, {"opacity": 0, "y": 12}, "power3.out", opacity=1, y=0)
        self.tl.to("#" + aid, b["e"] - 0.15, 0.15, "power1.in", opacity=0)
        self.snaps.append(b["s"] + 0.6)

    # ---------- beats: creator (stickers over video) ----------
    def cr_top(self):
        return self.L["text_top"] - 10

    def emoji_or_icon(self, it, size):
        if it.get("emoji") and self.emoji_ok:
            return f'<span class="emo" style="font-size:{size}px">{esc(it["emoji"])}</span>'
        return f'<div class="dot cdot" style="width:{size}px;height:{size}px">{self.icon(it.get("icon"))}</div>'

    def wiggle(self, sel, t):
        for j, r in enumerate([-9, 7, -4, 2, 0]):
            self.tl.to(sel, t + 0.3 + j * 0.07, 0.07, "sine.inOut", rotation=r)

    def cr_wrap(self, b, inner, top, cls="", enter=True):
        bid = self.uid("b")
        self.layer["vis"].append(f'<div class="cvis {cls}" id="{bid}" style="top:{top}px">{inner}</div>')
        if enter:
            self.tl.fromto("#" + bid, b["s"] - 0.02, 0.1, {"opacity": 0}, "none", opacity=1)
        self.tl.to("#" + bid, b["e"] - 0.2, 0.18, "power1.in", opacity=0)
        self.snaps.append(b["s"] + 0.65 * (b["e"] - b["s"]))
        return bid

    def cr_icons(self, b):
        items = (b.get("items") or [b])[:4]
        ats = self.spread(items, b["s"], b["e"])
        bid = self.uid("ci")
        size = 150 if len(items) <= 2 else 120
        parts = []
        for k, (it, t) in enumerate(zip(items, ats)):
            iid = f"{bid}i{k}"
            rot = -6 if k % 2 == 0 else 5
            parts.append(f'<div class="cit" id="{iid}">{self.emoji_or_icon(it, size)}'
                         f'<div class="marker" style="transform:rotate({rot}deg)">{esc(it.get("label", ""))}</div></div>')
            self.tl.fromto("#" + iid, t, 0.32, {"opacity": 0, "scale": 0.2}, "back.out(2.2)", opacity=1, scale=1)
            self.wiggle("#" + iid, t)
            self.sfx(t, "pop", -2)
        self.cr_wrap(b, "".join(parts), self.cr_top() + 105, "row")

    def cr_versus(self, b):
        L, R = b.get("left", {}), b.get("right", {})
        rev = self.T(b.get("reveal_at"), b["s"] + 0.45 * (b["e"] - b["s"]))
        bid = self.uid("cv")
        inner = (f'<div class="card cl" id="{bid}L">{esc(str(L.get("label", "")))}'
                 f'<svg class="scrib" viewBox="0 0 400 140" preserveAspectRatio="none"><path id="{bid}S" pathLength="1" '
                 f'd="M10 70 L60 20 L95 120 L140 25 L180 118 L225 22 L265 116 L305 28 L345 112 L390 60"/></svg></div>'
                 f'<div class="card cr" id="{bid}R">{esc(str(R.get("label", "")))}</div>')
        self.tl.fromto(f"#{bid}L", b["s"] + 0.2, 0.3, {"opacity": 0, "scale": 1.4}, "back.out(1.8)", opacity=1, scale=1)
        self.tl.set(f"#{bid}S", 0, strokeDashoffset=1)
        self.draw(f"#{bid}S", rev, 0.35)
        self.tl.fromto(f"#{bid}R", rev + 0.3, 0.32, {"opacity": 0, "scale": 1.7, "rotation": 12}, "back.out(1.6)", opacity=1, scale=1, rotation=3)
        self.sfx(b["s"] + 0.2, "pop", -3); self.sfx(rev, "scribble", -3); self.sfx(rev + 0.3, "impact", -6)
        self.shake(rev + 0.42, 10)
        self.cr_wrap(b, inner, self.cr_top() + 115, "row")

    def cr_rows(self, b, marks):
        items = (b.get("items") or [])[:5]
        ats = self.spread(items, b["s"], b["e"])
        bid = self.uid("cn")
        parts = []
        for k, (it, t) in enumerate(zip(items, ats)):
            it = it if isinstance(it, dict) else {"text": it}
            mk = it.get("mark", "check") if marks else "check"
            rid = f"{bid}r{k}"
            path = "M8 30 L24 46 L56 10" if mk != "x" else "M10 10 L50 50 M50 10 L10 50"
            parts.append(f'<div class="nrow" id="{rid}"><svg class="tick {"tx" if mk == "x" else ""}" viewBox="0 0 60 60">'
                         f'<path id="{rid}p" pathLength="1" d="{path}"/></svg><span>{esc(str(it.get("text", "")))}</span></div>')
            self.tl.fromto("#" + rid, t, 0.25, {"opacity": 0, "x": -20}, "power3.out", opacity=1, x=0)
            self.tl.set(f"#{rid}p", 0, strokeDashoffset=1)
            self.draw(f"#{rid}p", t + 0.15, 0.28)
            if mk == "x":
                for j, x in enumerate([-12, 10, -7, 4, 0]):
                    self.tl.to("#" + rid, t + 0.45 + j * 0.05, 0.05, "none", x=x)
                self.sfx(t + 0.4, "buzz", -4)
            else:
                self.sfx(t + 0.15, "tick", -2)
        if b.get("stamp"):
            st = self.T(b.get("stamp_at"), b["e"] - 1.1)
            parts.append(f'<div class="cstamp" id="{bid}s">{esc(str(b["stamp"]).upper())}</div>')
            self.tl.fromto(f"#{bid}s", st, 0.25, {"opacity": 0, "scale": 2.2, "rotation": -20}, "power4.out", opacity=1, scale=1, rotation=-10)
            self.shake(st + 0.2, 12)
            self.sfx(st, "stamp", 0)
            self.snaps.append(st + 0.4)
        bid2 = self.cr_wrap(b, f'<div class="note">{"".join(parts)}</div>', self.cr_top() + 95, "", enter=False)
        self.tl.fromto("#" + bid2, b["s"], 0.35, {"opacity": 0, "y": 60, "rotation": -6}, "back.out(1.5)", opacity=1, y=0, rotation=-2)
        self.sfx(b["s"], "whoosh", -6)

    def cr_flow(self, b):
        steps = (b.get("steps") or b.get("items") or [])[:4]
        ats = self.spread(steps, b["s"], b["e"])
        bid = self.uid("cf")
        parts = []
        for k, (it, t) in enumerate(zip(steps, ats)):
            if k:
                aid = f"{bid}a{k}"
                parts.append(f'<svg class="arr" viewBox="0 0 80 40"><path id="{aid}" pathLength="1" d="M4 24 Q40 0 72 20 M60 8 L74 21 L58 30"/></svg>')
                self.tl.set("#" + aid, 0, strokeDashoffset=1)
                self.draw("#" + aid, t - 0.25, 0.25)
            sid = f"{bid}s{k}"
            parts.append(f'<div class="cit sm" id="{sid}">{self.emoji_or_icon(it, 96)}<div class="marker sm">{esc(it.get("label", ""))}</div></div>')
            self.tl.fromto("#" + sid, t, 0.3, {"opacity": 0, "scale": 0.2}, "back.out(2.2)", opacity=1, scale=1)
            self.sfx(t, "pop", -4)
        self.cr_wrap(b, "".join(parts), self.cr_top() + 120, "row flowc")

    def cr_count(self, b):
        n = int(b.get("to", 30))
        bid = self.uid("cc")
        vals = sorted({round(n * j / min(n, 60)) for j in range(0, min(n, 60) + 1)})
        t0, D = b["s"] + 0.2, min(1.6, max(0.7, (b["e"] - b["s"]) * 0.4))
        times = [t0 + D * (1 - (1 - v / n) ** 2) for v in vals]
        nums = "".join(f'<span id="{bid}n{k}">{v}{esc(b.get("suffix", ""))}</span>' for k, v in enumerate(vals))
        cells = min(n, 60) if b.get("grid", True) else 0
        cols = 10 if cells > 20 else max(1, cells)
        cw = int(min(52, 860 / max(1, cols) - 12))
        grid = "".join(f'<i id="{bid}c{k}" style="width:{cw}px;height:{cw}px"></i>' for k in range(cells))
        inner = f'<div class="cnum">{nums}</div><div class="ccells" style="grid-template-columns:repeat({cols},{cw}px)">{grid}</div>'
        self.cr_wrap(b, inner, self.cr_top() + 70, "col center")
        self.tl.set(f"#{bid}n0", b["s"], opacity=1)
        for k in range(1, len(vals)):
            self.tl.set(f"#{bid}n{k - 1}", times[k], opacity=0)
            self.tl.set(f"#{bid}n{k}", times[k], opacity=1)
        for k in range(cells):
            v = (k + 1) * n / cells
            idx = min(range(len(vals)), key=lambda j: abs(vals[j] - v))
            self.tl.set(f"#{bid}c{k}", times[idx], backgroundColor="#FFE14D")
        self.sfx(b["s"] - 1.1, "riser", -6)
        self.sfx(times[-1], "impact", 0)
        self.shake(times[-1], 18)
        self.flash(times[-1])
        self.snaps.append(times[-1] + 0.35)

    def cr_aside(self, b):
        aid = self.uid("ca")
        inner = (f'<svg class="arr big" viewBox="0 0 120 90"><path id="{aid}p" pathLength="1" d="M100 80 Q30 70 22 14 M8 30 L22 12 L38 28"/></svg>'
                 f'<div class="marker note2">{esc(b.get("text", ""))}</div>')
        self.tl.set(f"#{aid}p", 0, strokeDashoffset=1)
        bid = self.cr_wrap(b, inner, self.cr_top() + 95, "row aside2", enter=False)
        self.tl.fromto("#" + bid, b["s"], 0.3, {"opacity": 0, "scale": 0.7}, "back.out(2)", opacity=1, scale=1)
        self.draw(f"#{aid}p", b["s"] + 0.1, 0.35)
        self.sfx(b["s"], "scribble", -8)

    def cr_endcard(self, b):
        press = max(b["s"] + 0.7, self.T(b.get("press_at"), b["s"] + 0.45 * (b["e"] - b["s"])))
        bid = self.uid("ce")
        inner = (f'<div class="marker note2" id="{bid}m">{esc(b.get("sub") or "follow along!")}</div>'
                 f'<div class="igf" id="{bid}f"><span id="{bid}f1">{esc(b.get("button", "Follow"))}</span>'
                 f'<span class="f2" id="{bid}f2">{esc(b.get("pressed", "Following"))}</span></div>')
        self.cr_wrap(b, inner, self.cr_top() + 95, "col center")
        self.tl.fromto(f"#{bid}m", b["s"] + 0.1, 0.3, {"opacity": 0, "rotation": -12, "scale": 1.3}, "back.out(2)", opacity=1, rotation=-4, scale=1)
        self.tl.fromto(f"#{bid}f", b["s"] + 0.3, 0.35, {"opacity": 0, "y": 40}, "back.out(1.8)", opacity=1, y=0)
        self.tl.to(f"#{bid}f", press, 0.08, "power2.in", scale=0.88)
        self.tl.to(f"#{bid}f", press + 0.08, 0.3, "back.out(3)", scale=1)
        self.tl.to(f"#{bid}f", press + 0.05, 0.12, "none", backgroundColor="#EFEFEF")
        self.tl.to(f"#{bid}f1", press + 0.05, 0.08, "none", opacity=0)
        self.tl.fromto(f"#{bid}f2", press + 0.05, 0.1, {"opacity": 0}, "none", opacity=1)
        self.sfx(press, "tap", 0); self.sfx(press + 0.12, "ding", -3)
        self.snaps.append(press + 0.5)

    # ---------- assemble ----------
    def beats_render(self):
        ed = self.style == "editorial"
        for b in self.beats:
            t = b["type"]
            if ed:
                {"icons": self.ed_icons, "sticker": self.ed_icons, "versus": self.ed_versus, "flow": self.ed_flow,
                 "endcard": self.ed_endcard, "count": self.ed_count, "aside": self.ed_aside,
                 "checklist": lambda x: self.ed_rows(x, False), "list": lambda x: self.ed_rows(x, True)
                 }.get(t, lambda x: self.warn.append(f"unknown beat type {t}"))(b)
            else:
                {"icons": self.cr_icons, "sticker": self.cr_icons, "versus": self.cr_versus, "flow": self.cr_flow,
                 "endcard": self.cr_endcard, "count": self.cr_count, "aside": self.cr_aside,
                 "checklist": lambda x: self.cr_rows(x, False), "list": lambda x: self.cr_rows(x, True)
                 }.get(t, lambda x: self.warn.append(f"unknown beat type {t}"))(b)

    def fonts(self, proj):
        os.makedirs(f"{proj}/assets/fonts", exist_ok=True)
        want = [("inter-tight", "Inter Tight", w, s) for w in (400, 500, 600, 700, 800) for s in ("normal",)] + \
               [("inter-tight", "Inter Tight", 400, "italic"), ("montserrat", "Montserrat", 800, "normal"),
                ("montserrat", "Montserrat", 900, "normal"), ("permanent-marker", "Permanent Marker", 400, "normal")]
        css = []
        for pkg, fam, wgt, sty in want:
            src = os.path.join(NM, "@fontsource", pkg, "files", f"{pkg}-latin-{wgt}-{sty}.woff2")
            if os.path.exists(src):
                shutil.copy(src, f"{proj}/assets/fonts/")
                css.append(f'@font-face{{font-family:"{fam}";src:url(assets/fonts/{os.path.basename(src)}) format("woff2");'
                           f'font-weight:{wgt};font-style:{sty};font-display:block}}')
        css.append('@font-face{font-family:"Noto Color Emoji";src:local("Noto Color Emoji")}')
        return "\n".join(css)

    def build(self):
        self.resolve(); self.camera(); self.labels(); self.text(); self.beats_render()
        proj = os.path.join(self.work, "project")
        if os.path.isdir(proj):
            shutil.rmtree(proj)
        os.makedirs(f"{proj}/assets")
        src = os.path.join(self.work, "cut.mp4")
        try:
            os.link(src, f"{proj}/assets/cut.mp4")
        except OSError:
            shutil.copy(src, f"{proj}/assets/cut.mp4")
        shutil.copy(os.path.join(NM, "gsap", "dist", "gsap.min.js"), f"{proj}/assets/gsap.min.js")
        fc = self.L["face_center"]
        css = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "reel.css")).read()
        tok = {"__ACCENT__": self.col["accent"], "__PAPER__": self.col["paper"], "__INK__": self.col["ink"],
               "__NEG__": self.col["neg"], "__GRID__": rgba(self.col["accent"], 0.13), "__FX__": str(fc[0]),
               "__FY__": str(fc[1]), "__PTOP__": str(self.L["panel_top"]), "__PH__": str(H - self.L["panel_top"] + 80)}
        for k, v in tok.items():
            css = css.replace(k, v)
        dur = f"{self.dur:.3f}"
        body = (f'<div id="root" data-composition-id="root" data-width="{W}" data-height="{H}" data-duration="{dur}" data-fps="{self.C.get("fps", 30)}" class="{self.style}">\n'
                f'<div id="cam"><div id="shake"><div id="punch"><video id="talent" class="clip" src="assets/cut.mp4" data-start="0" '
                f'data-duration="{dur}" data-track-index="0" muted playsinline></video></div></div></div>\n'
                + ('<div id="paper"></div>\n' if self.style == "editorial" else "")
                + "".join(f'<div class="layer L-{k}">' + "\n".join(v) + "</div>\n" for k, v in self.layer.items())
                + '<div id="flash"></div>\n</div>')
        js = ("const tl = gsap.timeline({paused:true});\n" + "\n".join(self.tl.out)
              + f'\ntl.set("#flash",{{opacity:0}},{self.dur - 0.001:.3f});\n'
              + 'window.__timelines = window.__timelines || {};\nwindow.__timelines["root"] = tl;\n')
        page = (f'<!doctype html>\n<html><head><meta charset="utf-8"><title>reel</title>\n<style>\n{self.fonts(proj)}\n{css}\n</style>\n'
                f'<script src="assets/gsap.min.js"></script>\n</head><body>\n{body}\n<script>\n{js}</script>\n</body></html>\n')
        open(f"{proj}/index.html", "w").write(page)
        json.dump(sorted(self.cues, key=lambda c: c["t"]), open(os.path.join(self.work, "cues.json"), "w"), indent=0)
        mus = self.sb.get("music", {"style": "chill-house"})
        if isinstance(mus, str):
            mus = None if mus.lower() in ("none", "off", "no", "") else {"style": mus}
        if mus:
            mus = dict(mus)
            drop = self.T(mus.get("drop_at"), None)
            if drop is None and self.pages:
                drop = self.pages[0][0]
            if drop is None:
                drop = next((b["s"] for b in self.beats if b["type"] == "count"), None)
            mus["drop_at"] = drop
        json.dump({"duration": self.dur, "music": mus, "sfx": self.level,
                   "levels": self.sb.get("levels", {})}, open(os.path.join(self.work, "audio_plan.json"), "w"), indent=1)
        snaps = sorted({round(min(self.dur - 0.05, max(0.05, t)), 2) for t in self.snaps})
        while len(snaps) > 12:
            snaps = snaps[::2] + ([snaps[-1]] if snaps[-1] not in snaps[::2] else [])
        open(os.path.join(self.work, "snapshot_times.txt"), "w").write(",".join(str(t) for t in snaps))
        print(f"built {proj}/index.html | style={self.style} | {self.dur:.2f}s | {len(self.beats)} beats | "
              f"{len(self.cues)} sfx cues | music={'off' if not mus else mus.get('style')} | snapshots: {','.join(map(str, snaps))}")
        for w in self.warn:
            print("WARNING:", w)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", required=True)
    Reel(ap.parse_args().work).build()
