#!/usr/bin/env bash
# Reel Editor: one-time environment setup for a claude.ai (or any Linux) sandbox.
# Idempotent: re-running only fills in what's missing. Takes ~2-3 minutes the first time.
# Installs: ffmpeg check, Python deps, Whisper small.en (sherpa-onnx export), a word-timing model,
# HyperFrames + GSAP + fonts + icons from npm, and wires HyperFrames to a local headless Chrome.
set -uo pipefail
RK="${REELKIT_HOME:-/home/claude/.reelkit}"
HF_VERSION="${REELKIT_HF_VERSION:-0.8.172}"   # pinned: the version this skill was tested with
REL="https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models"
mkdir -p "$RK/models" "$RK/node"
ok(){ printf '  ok   %s\n' "$*"; }
bad(){ printf '  FAIL %s\n' "$*"; FAILS=$((FAILS+1)); }
note(){ printf '  note %s\n' "$*"; }
FAILS=0
echo "Reel Editor setup -> $RK"

# 1. ffmpeg / ffprobe ----------------------------------------------------------
if ! command -v ffmpeg >/dev/null || ! command -v ffprobe >/dev/null; then
  (apt-get install -y -qq ffmpeg >/dev/null 2>&1 || { apt-get update -qq >/dev/null 2>&1 && apt-get install -y -qq ffmpeg >/dev/null 2>&1; })
fi
command -v ffprobe >/dev/null && ok "ffmpeg $(ffmpeg -version | head -1 | awk '{print $3}')" || bad "ffmpeg missing (apt-get install ffmpeg failed)"

# 2. Python packages -------------------------------------------------------------
if ! python3 -c "import numpy, scipy, cv2, sherpa_onnx, PIL" 2>/dev/null; then
  pip install -q --break-system-packages numpy scipy opencv-python-headless sherpa-onnx pillow >/dev/null 2>&1 \
    || pip install -q numpy scipy opencv-python-headless sherpa-onnx pillow >/dev/null 2>&1
fi
python3 -c "import numpy, scipy, cv2, sherpa_onnx, PIL" 2>/dev/null && ok "python packages" || bad "python packages (numpy scipy opencv sherpa-onnx pillow)"

# 3. Whisper (sherpa-onnx int8 export). small.en preferred, base.en fallback -----------
fetch_model(){ # $1 = release asset name, $2 = tar wildcard(s)
  local name="$1"; shift
  [ -d "$RK/models/$name" ] && [ -n "$(ls "$RK/models/$name"/*.onnx 2>/dev/null)" ] && return 0
  timeout 900 bash -c "curl -fsSL '$REL/$name.tar.bz2' | tar -xjf - -C '$RK/models' $*" 2>/dev/null
  [ -n "$(ls "$RK/models/$name"/*.onnx 2>/dev/null)" ]
}
WHISPER=""
for m in small.en base.en; do
  pre="/home/claude/models/sherpa-onnx-whisper-$m"   # some sandboxes ship models here
  if [ -f "$pre/$m-decoder.int8.onnx" ] && [ ! -e "$RK/models/sherpa-onnx-whisper-$m" ]; then ln -s "$pre" "$RK/models/sherpa-onnx-whisper-$m"; fi
  if fetch_model "sherpa-onnx-whisper-$m" --wildcards "'*int8*'" "'*tokens*'"; then WHISPER="$m"; break; fi
done
[ -n "$WHISPER" ] && ok "Whisper $WHISPER" || bad "Whisper model download (needs github.com in the network allowlist)"

# 4. Word-timing model (CTC). Optional: transcription still works without it, timing is coarser
ALIGN=""
for m in sherpa-onnx-nemo-parakeet_tdt_ctc_110m-en-36000-int8 sherpa-onnx-nemo-ctc-en-conformer-small; do
  if fetch_model "$m" --wildcards "'*.onnx'" "'*tokens.txt'"; then ALIGN="$m"; break; fi
done
[ -n "$ALIGN" ] && ok "word-timing model" || note "word-timing model unavailable; using pause-aware timing"

# 5. HyperFrames, GSAP, fonts, icons (npm) ------------------------------------------
cd "$RK/node" || exit 1
[ -f package.json ] || npm init -y >/dev/null 2>&1
if [ ! -x node_modules/.bin/hyperframes ] || [ ! -d node_modules/lucide-static ]; then
  PKGS="gsap @fontsource/inter-tight @fontsource/montserrat @fontsource/permanent-marker lucide-static"
  timeout 600 npm i --no-audit --no-fund --loglevel=error "hyperframes@$HF_VERSION" $PKGS >/dev/null 2>&1 \
    || timeout 600 npm i --no-audit --no-fund --loglevel=error hyperframes $PKGS >/dev/null 2>&1
fi
if [ -x node_modules/.bin/hyperframes ]; then
  ok "HyperFrames $(node -p 'require("./node_modules/hyperframes/package.json").version')"
  node_modules/.bin/hyperframes telemetry disable >/dev/null 2>&1 || true
else bad "HyperFrames npm install"; fi
[ -f node_modules/gsap/dist/gsap.min.js ] && ok "GSAP, fonts, icons" || bad "GSAP/fonts/icons npm install"

# 6. Headless Chrome for rendering ----------------------------------------------------
CHROME=""
for c in /home/claude/.cache/puppeteer/chrome-headless-shell/*/chrome-headless-shell-linux64/chrome-headless-shell \
         "$HOME"/.cache/puppeteer/chrome-headless-shell/*/chrome-headless-shell-linux64/chrome-headless-shell \
         /opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell \
         "$HOME"/.cache/ms-playwright/chromium_headless_shell-*/chrome-linux/headless_shell \
         /opt/pw-browsers/chromium-*/chrome-linux/chrome \
         "$HOME"/.cache/ms-playwright/chromium-*/chrome-linux/chrome \
         "$(command -v chromium 2>/dev/null)" "$(command -v google-chrome 2>/dev/null)"; do
  [ -n "$c" ] && [ -x "$c" ] && { CHROME="$c"; break; }
done
if [ -z "$CHROME" ]; then
  timeout 300 node_modules/.bin/hyperframes browser ensure >/dev/null 2>&1 && CHROME="$(node_modules/.bin/hyperframes browser path 2>/dev/null | tail -1)"
fi
[ -n "$CHROME" ] && [ -x "$CHROME" ] && ok "Chrome: $CHROME" || bad "no headless Chrome found"

# 7. Emoji font (creator style only; optional) ------------------------------------------
fc-list 2>/dev/null | grep -i "Noto Color Emoji" >/dev/null || { apt-get install -y -qq fonts-noto-color-emoji >/dev/null 2>&1; fc-cache -f >/dev/null 2>&1; }
fc-list 2>/dev/null | grep -i "Noto Color Emoji" >/dev/null && ok "emoji font" || note "emoji font missing; creator style falls back to icons"

# 8. env file ----------------------------------------------------------------------------
cat > "$RK/env.sh" <<EOF
export REELKIT_HOME="$RK"
export REELKIT_WHISPER="$RK/models/sherpa-onnx-whisper-$WHISPER"
export REELKIT_WHISPER_NAME="$WHISPER"
export REELKIT_ALIGN="${ALIGN:+$RK/models/$ALIGN}"
export HYPERFRAMES_BROWSER_PATH="$CHROME"
export PRODUCER_HEADLESS_SHELL_PATH="$CHROME"
export PATH="$RK/node/node_modules/.bin:\$PATH"
EOF
if [ "$FAILS" -eq 0 ]; then echo "READY (env: $RK/env.sh)"; else echo "NOT READY: $FAILS problem(s) above. See references/troubleshooting.md"; exit 1; fi
