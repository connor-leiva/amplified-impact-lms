---
name: reel-editor
description: Edits a talking-head video into an upload-ready vertical Reel/TikTok/Short inside Claude. Whisper transcribes it, dead space and retakes are cut with locked lip sync, HyperFrames animations explain what the speaker is saying (clean "editorial" graph-paper look or bold CapCut-style "creator" look), word-synced kinetic captions, original sound effects and music sit under the voice, and it renders to MP4. Use this whenever someone uploads a selfie, talking-head, or vertical video and wants it edited, tightened, captioned, animated, made more engaging, given sound effects or music, turned into a Reel/TikTok/Short, or styled like a reference video, even if they never say HyperFrames or Whisper. Also use it for follow-up changes to a video made this way (voice louder, effects quieter, graphics lower, different look, new music).
---

# Reel Editor

Turns a raw talking-head clip into a finished Reel: tight cuts, animated explainer graphics timed to the words, captions, sound design, music, and an upload-ready MP4. Scripts do the heavy lifting; your job is the editorial judgment (what to cut, what to show, when) and quality control.

`S` below means the folder this SKILL.md lives in (shown as this skill's location, e.g. `/mnt/skills/user/reel-editor`). `W` means the work folder for this video: `/home/claude/reels/<short-name>`. The skill folder is read-only; everything you make goes in `W`.

## Ground rules

- Run scripts exactly as shown, with `bash` or `python3` in front. The tool shell is `/bin/sh`, so avoid bash-only syntax in your own commands (no `source`, no `{a,b}` braces).
- One video needs roughly 20 to 25 tool calls and some waiting: rendering takes about 10 seconds per second of video (a 45-second Reel takes about 8 minutes). The render runs in the background and survives between tool calls.
- If a turn ends before the video is done, the user says "continue". Run `bash S/scripts/render.sh status W` and pick up at the first step not done. Never redo finished steps.
- Don't write custom rendering code per video. The storyboard file is the creative control surface; edit the scripts only to fix a real bug.
- HyperFrames' own `transcribe` command can't download its Whisper models in this sandbox. `transcribe.py` is the working route; use it.

## Step 0: Intake

1. `ls /mnt/user-data/uploads`. If there's no video, ask for one: vertical (9:16) works best, under about 60 seconds, face in the upper half of the frame. If the file is too big to upload, they can export at 1080p.
2. Decide style, music, and series tag. If the user already said (or said "just do it"), don't ask; use defaults: editorial style, original music, no series tag. Otherwise run Steps 1 to 4 first, then ask once (with tappable options if that tool exists; asking ends your turn) and continue from Step 5 when they answer. The questions:
   - Look: **Editorial** (clean graph-paper split screens, kinetic type; calm and premium) or **Creator** (emoji stickers, highlight-box captions, marker notes, punchy hits)
   - Music: **Original background track** or **No music** (they add a trending sound in Instagram)
   - Series tag or handle to show, e.g. "day 1 of 30" and "@handle" (optional)
3. Tell the user once, up front, roughly how long rendering will take.

## Step 1: Setup (first run about 2 to 3 minutes, later runs about 5 seconds)

```
bash S/scripts/setup.sh
```
It must end with `READY`. If not, read `S/references/troubleshooting.md`.

## Step 2: Transcribe

```
python3 S/scripts/transcribe.py /mnt/user-data/uploads/<video> --work W
```
Read the printed transcript (also in `W/transcript.txt`). Each word has an index (`12:word`). Look for:
- **Retakes**: the same sentence said twice. Keep the last complete take; remove the earlier attempt, including any "um" before the restart.
- **False starts and stray fillers** ("um", "uh", "so, so") at the start of phrases.
- Grammar slips you'd fix on screen only (note them for `fix` in the storyboard; the audio stays as spoken).

## Step 3: Cut dead space and flubs

```
python3 S/scripts/cut.py --work W --remove "w11-w19,w40-w41"
```
`--remove` takes word ranges (inclusive) or seconds (`31.2-32.0`); leave it off if nothing needs removing. Pauses longer than 0.30 s are trimmed (change with `--max-gap`; use 0.45 for a calmer pace). Confirm the line says `frames N/N OK`. From here on, all times live on the new timeline in `W/transcript_cut.txt`, and word indices stay the same as in the original transcript.

## Step 4: Check the framing

```
python3 S/scripts/analyze.py layout --work W
```
View `W/layout_check.jpg` once. The yellow box should sit on the face, and the green "text" line should be below the chin. Graphics start at the green line, and split-screen panels start at the orange line. If the face wasn't detected or the lines are wrong, set corrected values in the storyboard's `layout` field (see the storyboard reference). The accent color is pulled from the outfit (e.g., a green blazer gives a deep green); the user's brand color overrides it.

## Step 5: Write the storyboard

Read `S/references/storyboard.md` (schema, beat types, examples), then write `W/storyboard.json`. For a different look than the two built in, also read `S/references/styles.md`. What makes it good:
- A visual moment every 3 to 6 seconds, timed to the words that motivate it. Anchor times to words (`"w23"`, `"w23.end"`) rather than guessing seconds.
- Graphics explain; they don't decorate. Show the idea the speaker is making (a comparison becomes `versus`, a sequence becomes `flow`, rules become `checklist`, a number becomes `count`).
- A hook title over the first 2 to 3 seconds, 3 to 6 short lowercase section labels, one big word per phrase, and an endcard with a follow call-to-action in the last 2 to 3 seconds.
- Beats never overlap; each lasts at least 1.5 s (`count` at least 2.5 s).

## Step 6: Build and look before rendering

```
python3 S/scripts/build.py --work W
bash S/scripts/render.sh check W
```
Fix every `WARNING:` line build.py prints. Lint must show 0 errors (the "file too large" warning is fine). Then view `W/check/sheet.jpg` and check for: anything covering the face, text running off the edges or into the bottom Instagram caption area, two graphics colliding, unreadable text. Adjust the storyboard and repeat (usually one round, at most two).

## Step 7: Render, and make the audio meanwhile

```
bash S/scripts/render.sh start W
python3 S/scripts/audio.py all --work W
bash S/scripts/render.sh wait W
```
Repeat `render.sh wait W` until it prints `RENDER DONE`; each call waits up to about 5 minutes, so a typical Reel needs one or two waits. `audio.py` prints the mix report: voice should lead, music about 15 dB under while talking, final about -14 LUFS. Don't run build.py while a render is running (it rebuilds the project folder the render reads).

## Step 8: Finish and deliver

```
bash S/scripts/render.sh finish W <file-name>
```
View `W/final_sheet.jpg` (frames pulled from the finished file) as a last check. Then present the files, main version first. `<file-name>.mp4` has the music; `<file-name>-no-music.mp4` is for adding a trending sound inside Instagram (set it around 10 to 15% so the voice stays on top). In the reply, briefly say what was cut (seconds and retakes), list the graphic moments in a sentence or two, and say what the sound is. Ask about any on-screen text fixes you made, and suggest one watch with sound before posting.

## Revisions: take the shortest path

| They want | Do | Re-render? |
|---|---|---|
| Voice louder, effects or music quieter or louder, different or no music | Edit `levels`, `sfx`, or `music` in the storyboard, then `build.py`, `audio.py all`, `render.sh finish` | No |
| Different words on a graphic, timing, add/remove a moment | Edit beats, then `build.py`, `check`, `start`, `wait`, `finish` | Yes |
| Graphics covering the face | Raise `layout.text_top` and `layout.panel_top` by 60 to 120 px, then rebuild and re-render | Yes |
| "Too corporate" / "too busy" | Switch `style` (creator / editorial), or set `sfx` to `punchy` / `subtle` | Yes |
| Cut more or less | `cut.py` again with a new `--max-gap` or `--remove`, then layout through finish | Yes |
| Match a reference video | See `S/references/styles.md` (matching a reference) | Yes |

Audio defaults (in `levels`, all in dB): `sfx_under_voice` 15 (editorial) or 12 (creator), `music_under_voice` 15, `music_gap_lift` 6, `lufs` -14, `true_peak` -1.5. "Effects are too loud" means raise `sfx_under_voice` by 4 to 6; "voice not prominent enough" means raise both `under_voice` values by about 3.

Instagram and TikTok links can't be opened from here (those sites block automated access). If someone shares one as a style reference, ask them to upload the video or 3 to 5 screenshots instead.
