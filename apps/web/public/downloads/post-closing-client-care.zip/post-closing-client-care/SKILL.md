---
name: post-closing-client-care
description: "Plans one client's first year after a closing and drafts personal touches from the deal's own facts: a dated plan (closing day, week 1, day 30, day 90, month 6, then the first anniversary handed to sphere-touch-plan), a card and thank-you email, a review request asked the same way of every client, vendor introductions only from the agent's own list, a property tax or homestead reminder that points to the county, and Follow Up Boss steps. Reads a TC's closing email, a Sisu or Follow Up Boss record or the agent's notes, plus a vendor list and review links. Texts only for clients who agreed; no review incentives or gating; no referral fees. Use it when an agent says we just closed, closing gift, thank-you card, ask for a review or past client care, even if they never say post-closing client care. Not for the cadence after year one (sphere-touch-plan), an appointment recap (appointment-follow-up), a contract-to-close file audit (tc-file-audit) or the weekly seller update while listed (seller-listing-update)."
compatibility: "Works from uploaded or pasted files with no connectors. Uses code execution, when it is on, to work out the plan's dates and weekdays."
metadata:
  author: Amplified Impact
  version: "1.0"
---

# Post-Closing Client Care

Plan one client's first year after a closing and draft the touches that make it personal: the card, the thank-you, a review request, introductions to the agent's own vendors and a property tax reminder that points to the county. Follow Up Boss action plans and automations can already remind an agent when a touch is due; this writes what to say from what this client actually cared about, and keeps the review and vendor rules.

Why it matters: the first year decides whether a client sends their friends. It's also where agents slip: a gift card for five stars, a review link sent only to the happy clients, a "my guy" who quietly pays a referral fee, or a card that mentions something the client said in confidence.

**Run:** reads the closing email or record and the notes, finds each client, the side, the property, the county and the closing date, works out every date in the plan, reads who agreed to texts, and matches the notes to the vendor list. **Draft:** the plan, the card text, the thank-you email, the review request, the vendor introductions, the property tax reminder and the Follow Up Boss steps, for the agent to read and send by hand. **Own:** what each client hears and when, every consent record, the vendor list and every relationship or payment behind it (and any disclosure form), the gift, setting up Follow Up Boss, and every tax, legal or insurance question, which goes to the county assessor or a professional. Nothing is sent, scheduled or written to a CRM.

## 1. Get the Deal and the Notes

- **The deal:** a TC's closing email, a Sisu or Follow Up Boss transaction record, or the agent's notes. Take each client's name and email, the side (buyer or seller), the property address, the closing date and the county. Read `references/client-care-guide.md` (Where the Deal Comes From).
- **The notes:** what the client loved, planned or asked for, the gift, and who agreed to texts. Optional: the agent's vendor list and review links.
- **Nothing to work from:** ask once for the closing email or record. Never invent a deal.
- **Missing facts:** a [placeholder] ([Review Link], [County], [Agent Name]), one flag, and keep going. Never ask the agent to retype what a document holds.
- Never carry the price, commission, loan, rate, wire or account details into the output, even when the email shows them.
- **Today:** the date in the agent's message, otherwise today's date.

## 2. Work Out the Dates

- **Closing date:** the recorded or closed date the deal shows. Signing and recording on different days: use the recording date and flag it. Not closed yet: plan from the scheduled date and flag it.
- **Plan dates,** from the closing date, in code when you can: closing day; week 1 (plus 7 days); day 30 (plus 30); day 90 (plus 90); month 6 (plus 182); first anniversary (the same month and day a year later; February 29 becomes February 28). Write each with its weekday.
- **Already past:** when a touch's date is before today, the closing-day touches go today and each later past touch goes two days after the one before it. Touches still ahead keep their dates. Flag each moved touch with its original date.
- **Calls:** no call or voicemail on a Sunday or a legal holiday (Utah mode: the Utah legal holidays in `references/utah-client-care.md`; general mode: Sundays and the federal legal holidays in the guide's Plan Dates, and say state holidays weren't checked). A call that would land on one, the day 90 call included, moves to the next day that is neither, with a one-line why and its original date. Texts, emails and the card keep their day.

## 3. Read the Notes

Use "What a Draft May Mention" in the guide.
- Use only what the notes or the deal say: what they loved about the home, a project they plan, something they asked for, a pet the notes name, the gift. Never invent children, pets, plans, hobbies or events, and never join two notes into a fact neither one says.
- **Left out on purpose,** even when the notes say it: health; money (price, loan, rate, payment, appraisal, equity, commission); family status and changes in it (pregnancy, marriage, divorce, children, grandchildren); religion, national origin, disability and age. One agent-only flag counts those notes without repeating them.
- **Fair housing:** describe the home, never the people or the neighborhood. No schools, safety or who lives nearby. Never call a client a family.

## 4. Choose Channels

- **Texts** only to a client the agent says agreed to texts, or whose record shows a written yes (a consent field, a signed form). A phone number, a past deal, a verbal-only yes, a blank, STOP, Do Not Text or Do Not Call is not consent. Read `references/outreach-rules.md` (the Checklist).
- Each text goes to one client, opens "Hi [First Name], it's [Agent Full Name] with [Brokerage]," holds one link at most, runs 300 characters or fewer, and ends "Reply STOP to opt out." Sent by hand, 8 a.m. to 8 p.m. their time.
- **Email** for every client with an address, unless Unsubscribed or Do Not Email. **Calls** unless Do Not Call.
- No client agreed to texts: no text drafts, and one flag says why.

## 5. Draft the Closing-Day Card and Thank-You Email

Use "Draft Shapes" in the guide.
- **Card:** two to four sentences in the agent's hand, to the clients by first name, naming one or two things from the notes and the gift if the notes name one. No links, no asks.
- **Thank-you email:** a Title Case subject, 150 words or fewer, a thank-you tied to the notes, and the next touch with its date. No review ask, no referral ask and no vendor pitch. It still carries the full footer from the guide, like every email.
- **Voice:** follow the user's voice profile QUICK CARD when one is in the conversation (amplifiedimpact.io/voice-profile), including its sign-off. Without one: warm, plain, direct. Sign with the user's name; otherwise [Agent Name]. None of "stunning," "dream home," "don't hesitate to reach out," "touch base" or "circle back."

## 6. Draft the Review Request

Read `references/reviews-and-vendors.md` (Reviews).
- **Week 1, the same ask for every client,** whatever the agent expects them to say: one email with every link from the agent's review links, and the same ask by text to each client who agreed to texts (the first link only). No links given: [Review Link], flagged.
- Ask for an honest review of their experience. Never mention stars, a rating or "five-star," never suggest what to write, never offer to write it, and never offer anything for it.
- **An incentive tied to a rating** ("a $50 gift card for a 5-star review"): decline that part in a flag, cite 16 CFR 465.4, and draft the compliant ask. Any other reward for a review (a gift, gift card, discount, drawing or donation, before or after the review, tied to the rating or not): decline it the same way (the reference says why).
- **Asked to ask only happy clients,** or to skip one because of how they might rate: draft the same ask anyway and flag that asking only happy clients is review gating (16 CFR 255.2(d) and its Example 11; Google's policy). Whether to send stays the agent's call, never decided by the rating they expect.
- The email carries the footer from the guide.

## 7. Draft the Vendor Introductions

Read `references/reviews-and-vendors.md` (Vendors).
- **Only vendors on the agent's own list, and only for a need the notes name:** the client asked for a name, or the notes say they plan work that trade does. Never invent a vendor, a name, a phone number or a service. No list: no introductions, and one line says so.
- **State every relationship the list discloses** (family, ownership, affiliation) in plain words, and say the client is free to use anyone.
- **A vendor the list shows pays the agent for referrals,** or gives anything of value for them: no introduction. Flag it, cite RESPA Section 8 (12 U.S.C. 2607(a)), and send the question to the broker.
- **An affiliated business** (the agent's brokerage or team owns part of it) that provides a settlement service (a lender, title, insurance or a home warranty): introduce it only with a flag to give the client the brokerage's Affiliated Business Arrangement Disclosure first (12 U.S.C. 2607(c)(4); 12 CFR 1024.15). Utah: `references/utah-client-care.md`.
- One email, Title Case subject, 150 words or fewer, with the full footer, the marketing line included, even when the client asked for the names. It goes on closing day when the client asked for a name; otherwise with the day 30 touch. No advice on coverage, price or which vendor is best.

## 8. Draft the Property Tax Reminder

- **Buyer, Utah home:** read `references/utah-client-care.md`. The day 30 email: a short check-in from the notes, then the reminder to watch for the county assessor's form about the home's primary residential exemption and return it by the date on it, with the assessor's link, and that tax questions go to the assessor or a tax professional. Never say whether they qualify, what they'll owe or what they'll save.
- **Buyer outside Utah (general mode):** the same email, pointing to that county's assessor to ask whether a homestead or primary residence exemption needs an application and by when, and the flag "State rules were not checked."
- **Seller:** no reminder for the sold home. If the notes say they bought a home they'll live in, the same reminder for that home's county; otherwise one line says why there is none, and the day 30 touch is a check-in.
- **County unknown:** [County], flagged, with the place to look it up.

## 9. Give the Follow Up Boss Steps

Use "Set It Up in Follow Up Boss" in the guide: one plan of task steps (classic action plan or Automations 2.0, whichever the account has), started on the client's profile on closing day, and the Home Anniversary handoff. Closing day already past: don't start it for this client; add the touches still ahead as tasks due on their dates. Say which steps need an admin. These are instructions; never set anything up or write to the CRM.

## Guardrails

- **Facts only from the inputs:** every name, date, fact and quote comes from the deal, the notes, the vendor list, the review links or the agent's message. Dates come from the closing date by the rules in step 2.
- **Reviews:** one ask for everyone, no gating, no star talk, and no reward of any kind for a review: no gift, gift card, discount, drawing or donation, before or after, tied to the rating or not.
- **Vendors:** only the agent's list, relationships stated, no referral fees or kickbacks, affiliated businesses with their disclosure.
- **Texts:** only with consent, the sender named, "Reply STOP to opt out," by hand, one at a time.
- **Conservative defaults:** every email carries the full footer, the thank-you and the vendor introductions included; no reward of any kind for a review; and no call or voicemail on a Sunday or a legal holiday. These are the house's conservative defaults, stricter than the law in places. Keep them unless the user says their own legal counsel approved a different rule; then follow theirs and say so in Check Before Sending.
- **Stay in lane:** not the CPA, attorney, insurance agent, lender or broker. No tax, legal, insurance or loan advice (no refinance, rate, coverage or savings talk). Point to the county assessor or a professional.
- **Privacy:** never ask for, repeat or handle wire, account, routing or Social Security numbers.
- **Drafts only:** never send, schedule, start a plan, tag or write to a CRM, even with a connector and even if asked.
- **State rules:** Utah mode for a Utah property; otherwise general mode, which says "State rules were not checked."

## Output, In This Order

1. **Flags**, only when they apply: touches already past and moved, a call moved off a Sunday or a legal holiday, placeholders, no text consent, a review incentive or gating request declined, vendor flags (referral fee, affiliated business, no list), two closing dates or not closed yet, county unknown, general mode, and "Left out on purpose" (a count)
2. **Bottom line** (three sentences max): who closed what and when, the first year in one line, and what to do first
3. **What I Used** (agent only): the deal facts and where each came from, today's date, who agreed to texts, and the notes, list and links used
4. **Your First-Year Plan:** a table of each touch, its date with weekday, what it is, the channel, and the talking point from the notes; the last row hands the first anniversary to sphere-touch-plan
5. **Closing Day:** the card text and the thank-you email
6. **Review Request:** the email, then each text
7. **Vendor Introductions:** the email, or one line on why there is none
8. **Property Tax Reminder:** the day 30 email, or one line on why there is none
9. **Set It Up in Follow Up Boss**
10. **Check Before Sending:** every date with "closing date plus N days," every fact a draft mentions with its source, each vendor as listed with its relationship, each review link, each text's consent record, quiet hours and Do Not Call, any call moved off a Sunday or a legal holiday, the email footer on every email, the county link, and state rules

If the agent asks for one piece ("just the card"), give it with the flags and Check Before Sending.
